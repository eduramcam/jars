package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Quantity;
import io.swagger.model.TimePeriod;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="An attachment by value or by reference. An attachment complements the description of an element, for example through a document, a video, a picture.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class AttachmentRefOrValue   {
  
  private String id = null;
  private String href = null;
  private String attachmentType = null;
  private String content = null;
  private String description = null;
  private String mimeType = null;
  private String name = null;
  private String url = null;
  private Quantity size = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;
  private String referredType = null;

  /**
   * Unique identifier for this particular attachment
   **/
  
  @ApiModelProperty(example = "4aafacbd-11ff-4dc8-b445-305f2215715f", value = "Unique identifier for this particular attachment")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * URI for this Attachment
   **/
  
  @ApiModelProperty(example = "http://host/Attachment/4aafacbd-11ff-4dc8-b445-305f2215715f", value = "URI for this Attachment")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Attachment type such as video, picture
   **/
  
  @ApiModelProperty(example = "video", value = "Attachment type such as video, picture")
  @JsonProperty("attachmentType")
  public String getAttachmentType() {
    return attachmentType;
  }
  public void setAttachmentType(String attachmentType) {
    this.attachmentType = attachmentType;
  }

  /**
   * The actual contents of the attachment object, if embedded, encoded as base64
   **/
  
  @ApiModelProperty(value = "The actual contents of the attachment object, if embedded, encoded as base64")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   * A narrative text describing the content of the attachment
   **/
  
  @ApiModelProperty(example = "Photograph of the Product", value = "A narrative text describing the content of the attachment")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Attachment mime type such as extension file for video, picture and document
   **/
  
  @ApiModelProperty(value = "Attachment mime type such as extension file for video, picture and document")
  @JsonProperty("mimeType")
  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   * The name of the attachment
   **/
  
  @ApiModelProperty(value = "The name of the attachment")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Uniform Resource Locator, is a web page address (a subset of URI)
   **/
  
  @ApiModelProperty(example = "http://host/Content/4aafacbd-11ff-4dc8-b445-305f2215715f", value = "Uniform Resource Locator, is a web page address (a subset of URI)")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   * The size of the attachment.
   **/
  
  @ApiModelProperty(value = "The size of the attachment.")
  @JsonProperty("size")
  public Quantity getSize() {
    return size;
  }
  public void setSize(Quantity size) {
    this.size = size;
  }

  /**
   * The period of time for which the attachment is valid
   **/
  
  @ApiModelProperty(value = "The period of time for which the attachment is valid")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   * The actual type of the target instance when needed for disambiguation.
   **/
  
  @ApiModelProperty(value = "The actual type of the target instance when needed for disambiguation.")
  @JsonProperty("@referredType")
  public String getReferredType() {
    return referredType;
  }
  public void setReferredType(String referredType) {
    this.referredType = referredType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    AttachmentRefOrValue attachmentRefOrValue = (AttachmentRefOrValue) o;
    return Objects.equals(id, attachmentRefOrValue.id) &&
        Objects.equals(href, attachmentRefOrValue.href) &&
        Objects.equals(attachmentType, attachmentRefOrValue.attachmentType) &&
        Objects.equals(content, attachmentRefOrValue.content) &&
        Objects.equals(description, attachmentRefOrValue.description) &&
        Objects.equals(mimeType, attachmentRefOrValue.mimeType) &&
        Objects.equals(name, attachmentRefOrValue.name) &&
        Objects.equals(url, attachmentRefOrValue.url) &&
        Objects.equals(size, attachmentRefOrValue.size) &&
        Objects.equals(validFor, attachmentRefOrValue.validFor) &&
        Objects.equals(baseType, attachmentRefOrValue.baseType) &&
        Objects.equals(schemaLocation, attachmentRefOrValue.schemaLocation) &&
        Objects.equals(type, attachmentRefOrValue.type) &&
        Objects.equals(referredType, attachmentRefOrValue.referredType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, attachmentType, content, description, mimeType, name, url, size, validFor, baseType, schemaLocation, type, referredType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class AttachmentRefOrValue {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    attachmentType: ").append(toIndentedString(attachmentType)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    referredType: ").append(toIndentedString(referredType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

