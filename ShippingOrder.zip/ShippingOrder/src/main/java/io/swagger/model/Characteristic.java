package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Any;
import io.swagger.model.CharacteristicRelationship;
import java.util.List;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="Describes a given characteristic of an object or entity through a name/value pair.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class Characteristic   {
  
  private String id = null;
  private String name = null;
  private String valueType = null;
  private List<CharacteristicRelationship> characteristicRelationship = new ArrayList<CharacteristicRelationship>();
  private Any value = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Unique identifier of the characteristic
   **/
  
  @ApiModelProperty(value = "Unique identifier of the characteristic")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Name of the characteristic
   **/
  
  @ApiModelProperty(required = true, value = "Name of the characteristic")
  @JsonProperty("name")
  @NotNull
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Data type of the value of the characteristic
   **/
  
  @ApiModelProperty(value = "Data type of the value of the characteristic")
  @JsonProperty("valueType")
  public String getValueType() {
    return valueType;
  }
  public void setValueType(String valueType) {
    this.valueType = valueType;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("characteristicRelationship")
  public List<CharacteristicRelationship> getCharacteristicRelationship() {
    return characteristicRelationship;
  }
  public void setCharacteristicRelationship(List<CharacteristicRelationship> characteristicRelationship) {
    this.characteristicRelationship = characteristicRelationship;
  }

  /**
   * The value of the characteristic
   **/
  
  @ApiModelProperty(required = true, value = "The value of the characteristic")
  @JsonProperty("value")
  @NotNull
  public Any getValue() {
    return value;
  }
  public void setValue(Any value) {
    this.value = value;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Characteristic characteristic = (Characteristic) o;
    return Objects.equals(id, characteristic.id) &&
        Objects.equals(name, characteristic.name) &&
        Objects.equals(valueType, characteristic.valueType) &&
        Objects.equals(characteristicRelationship, characteristic.characteristicRelationship) &&
        Objects.equals(value, characteristic.value) &&
        Objects.equals(baseType, characteristic.baseType) &&
        Objects.equals(schemaLocation, characteristic.schemaLocation) &&
        Objects.equals(type, characteristic.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, name, valueType, characteristicRelationship, value, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Characteristic {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    valueType: ").append(toIndentedString(valueType)).append("\n");
    sb.append("    characteristicRelationship: ").append(toIndentedString(characteristicRelationship)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

