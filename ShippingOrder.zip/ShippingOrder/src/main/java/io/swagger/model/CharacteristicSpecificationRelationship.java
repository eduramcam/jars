package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.TimePeriod;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="An aggregation, migration, substitution, dependency or exclusivity relationship between/among Characteristic specifications. The specification characteristic is embedded within the specification whose ID and href are in this entity, and identified by its ID.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class CharacteristicSpecificationRelationship   {
  
  private String characteristicSpecificationId = null;
  private String name = null;
  private String parentSpecificationHref = null;
  private String parentSpecificationId = null;
  private String relationshipType = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Unique identifier of the characteristic within the specification
   **/
  
  @ApiModelProperty(value = "Unique identifier of the characteristic within the specification")
  @JsonProperty("characteristicSpecificationId")
  public String getCharacteristicSpecificationId() {
    return characteristicSpecificationId;
  }
  public void setCharacteristicSpecificationId(String characteristicSpecificationId) {
    this.characteristicSpecificationId = characteristicSpecificationId;
  }

  /**
   * Name of the target characteristic within the specification
   **/
  
  @ApiModelProperty(value = "Name of the target characteristic within the specification")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Hyperlink reference to the parent specification containing the target characteristic
   **/
  
  @ApiModelProperty(value = "Hyperlink reference to the parent specification containing the target characteristic")
  @JsonProperty("parentSpecificationHref")
  public String getParentSpecificationHref() {
    return parentSpecificationHref;
  }
  public void setParentSpecificationHref(String parentSpecificationHref) {
    this.parentSpecificationHref = parentSpecificationHref;
  }

  /**
   * Unique identifier of the parent specification containing the target characteristic
   **/
  
  @ApiModelProperty(value = "Unique identifier of the parent specification containing the target characteristic")
  @JsonProperty("parentSpecificationId")
  public String getParentSpecificationId() {
    return parentSpecificationId;
  }
  public void setParentSpecificationId(String parentSpecificationId) {
    this.parentSpecificationId = parentSpecificationId;
  }

  /**
   * Type of relationship such as aggregation, migration, substitution, dependency, exclusivity
   **/
  
  @ApiModelProperty(value = "Type of relationship such as aggregation, migration, substitution, dependency, exclusivity")
  @JsonProperty("relationshipType")
  public String getRelationshipType() {
    return relationshipType;
  }
  public void setRelationshipType(String relationshipType) {
    this.relationshipType = relationshipType;
  }

  /**
   * The period for which the object is valid
   **/
  
  @ApiModelProperty(value = "The period for which the object is valid")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CharacteristicSpecificationRelationship characteristicSpecificationRelationship = (CharacteristicSpecificationRelationship) o;
    return Objects.equals(characteristicSpecificationId, characteristicSpecificationRelationship.characteristicSpecificationId) &&
        Objects.equals(name, characteristicSpecificationRelationship.name) &&
        Objects.equals(parentSpecificationHref, characteristicSpecificationRelationship.parentSpecificationHref) &&
        Objects.equals(parentSpecificationId, characteristicSpecificationRelationship.parentSpecificationId) &&
        Objects.equals(relationshipType, characteristicSpecificationRelationship.relationshipType) &&
        Objects.equals(validFor, characteristicSpecificationRelationship.validFor) &&
        Objects.equals(baseType, characteristicSpecificationRelationship.baseType) &&
        Objects.equals(schemaLocation, characteristicSpecificationRelationship.schemaLocation) &&
        Objects.equals(type, characteristicSpecificationRelationship.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(characteristicSpecificationId, name, parentSpecificationHref, parentSpecificationId, relationshipType, validFor, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CharacteristicSpecificationRelationship {\n");
    
    sb.append("    characteristicSpecificationId: ").append(toIndentedString(characteristicSpecificationId)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    parentSpecificationHref: ").append(toIndentedString(parentSpecificationHref)).append("\n");
    sb.append("    parentSpecificationId: ").append(toIndentedString(parentSpecificationId)).append("\n");
    sb.append("    relationshipType: ").append(toIndentedString(relationshipType)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

