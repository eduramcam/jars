package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Money;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="Provides all amounts (tax included, duty free, tax rate), used currency and percentage to apply for Price Alteration.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class Price   {
  
  private String id = null;
  private String href = null;
  private Float percentage = null;
  private Float taxRate = null;
  private Money dutyFreeAmount = null;
  private Money taxIncludedAmount = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Percentage to apply for ProdOfferPriceAlteration
   **/
  
  @ApiModelProperty(value = "Percentage to apply for ProdOfferPriceAlteration")
  @JsonProperty("percentage")
  public Float getPercentage() {
    return percentage;
  }
  public void setPercentage(Float percentage) {
    this.percentage = percentage;
  }

  /**
   * Tax rate
   **/
  
  @ApiModelProperty(value = "Tax rate")
  @JsonProperty("taxRate")
  public Float getTaxRate() {
    return taxRate;
  }
  public void setTaxRate(Float taxRate) {
    this.taxRate = taxRate;
  }

  /**
   * All taxes excluded amount (expressed in the given currency)
   **/
  
  @ApiModelProperty(value = "All taxes excluded amount (expressed in the given currency)")
  @JsonProperty("dutyFreeAmount")
  public Money getDutyFreeAmount() {
    return dutyFreeAmount;
  }
  public void setDutyFreeAmount(Money dutyFreeAmount) {
    this.dutyFreeAmount = dutyFreeAmount;
  }

  /**
   * All taxes included amount (expressed in the given currency)
   **/
  
  @ApiModelProperty(value = "All taxes included amount (expressed in the given currency)")
  @JsonProperty("taxIncludedAmount")
  public Money getTaxIncludedAmount() {
    return taxIncludedAmount;
  }
  public void setTaxIncludedAmount(Money taxIncludedAmount) {
    this.taxIncludedAmount = taxIncludedAmount;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Price price = (Price) o;
    return Objects.equals(id, price.id) &&
        Objects.equals(href, price.href) &&
        Objects.equals(percentage, price.percentage) &&
        Objects.equals(taxRate, price.taxRate) &&
        Objects.equals(dutyFreeAmount, price.dutyFreeAmount) &&
        Objects.equals(taxIncludedAmount, price.taxIncludedAmount) &&
        Objects.equals(baseType, price.baseType) &&
        Objects.equals(schemaLocation, price.schemaLocation) &&
        Objects.equals(type, price.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, percentage, taxRate, dutyFreeAmount, taxIncludedAmount, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Price {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    percentage: ").append(toIndentedString(percentage)).append("\n");
    sb.append("    taxRate: ").append(toIndentedString(taxRate)).append("\n");
    sb.append("    dutyFreeAmount: ").append(toIndentedString(dutyFreeAmount)).append("\n");
    sb.append("    taxIncludedAmount: ").append(toIndentedString(taxIncludedAmount)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

