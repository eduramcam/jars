package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Price;
import io.swagger.model.ProductOfferingPriceRef;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="Is an amount, usually of money, that modifies the price charged for an order item.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class PriceAlteration   {
  
  private String id = null;
  private String href = null;
  private Integer applicationDuration = null;
  private String description = null;
  private String name = null;
  private String priceType = null;
  private Integer priority = null;
  private String recurringChargePeriod = null;
  private String unitOfMeasure = null;
  private Price price = null;
  private ProductOfferingPriceRef productOfferingPrice = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Duration during which the alteration applies on the order item price (for instance 2 months free of charge for the recurring charge)
   **/
  
  @ApiModelProperty(value = "Duration during which the alteration applies on the order item price (for instance 2 months free of charge for the recurring charge)")
  @JsonProperty("applicationDuration")
  public Integer getApplicationDuration() {
    return applicationDuration;
  }
  public void setApplicationDuration(Integer applicationDuration) {
    this.applicationDuration = applicationDuration;
  }

  /**
   * A narrative that explains in detail the semantics of this order item price alteration
   **/
  
  @ApiModelProperty(value = "A narrative that explains in detail the semantics of this order item price alteration")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Name of the order item price alteration
   **/
  
  @ApiModelProperty(value = "Name of the order item price alteration")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * A category that describes the price such as recurring, one time and usage.
   **/
  
  @ApiModelProperty(required = true, value = "A category that describes the price such as recurring, one time and usage.")
  @JsonProperty("priceType")
  @NotNull
  public String getPriceType() {
    return priceType;
  }
  public void setPriceType(String priceType) {
    this.priceType = priceType;
  }

  /**
   * Priority level for applying this alteration among all the defined alterations on the order item price
   **/
  
  @ApiModelProperty(value = "Priority level for applying this alteration among all the defined alterations on the order item price")
  @JsonProperty("priority")
  public Integer getPriority() {
    return priority;
  }
  public void setPriority(Integer priority) {
    this.priority = priority;
  }

  /**
   * Could be month, week...
   **/
  
  @ApiModelProperty(value = "Could be month, week...")
  @JsonProperty("recurringChargePeriod")
  public String getRecurringChargePeriod() {
    return recurringChargePeriod;
  }
  public void setRecurringChargePeriod(String recurringChargePeriod) {
    this.recurringChargePeriod = recurringChargePeriod;
  }

  /**
   * Could be minutes, GB...
   **/
  
  @ApiModelProperty(value = "Could be minutes, GB...")
  @JsonProperty("unitOfMeasure")
  public String getUnitOfMeasure() {
    return unitOfMeasure;
  }
  public void setUnitOfMeasure(String unitOfMeasure) {
    this.unitOfMeasure = unitOfMeasure;
  }

  /**
   **/
  
  @ApiModelProperty(required = true, value = "")
  @JsonProperty("price")
  @NotNull
  public Price getPrice() {
    return price;
  }
  public void setPrice(Price price) {
    this.price = price;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productOfferingPrice")
  public ProductOfferingPriceRef getProductOfferingPrice() {
    return productOfferingPrice;
  }
  public void setProductOfferingPrice(ProductOfferingPriceRef productOfferingPrice) {
    this.productOfferingPrice = productOfferingPrice;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PriceAlteration priceAlteration = (PriceAlteration) o;
    return Objects.equals(id, priceAlteration.id) &&
        Objects.equals(href, priceAlteration.href) &&
        Objects.equals(applicationDuration, priceAlteration.applicationDuration) &&
        Objects.equals(description, priceAlteration.description) &&
        Objects.equals(name, priceAlteration.name) &&
        Objects.equals(priceType, priceAlteration.priceType) &&
        Objects.equals(priority, priceAlteration.priority) &&
        Objects.equals(recurringChargePeriod, priceAlteration.recurringChargePeriod) &&
        Objects.equals(unitOfMeasure, priceAlteration.unitOfMeasure) &&
        Objects.equals(price, priceAlteration.price) &&
        Objects.equals(productOfferingPrice, priceAlteration.productOfferingPrice) &&
        Objects.equals(baseType, priceAlteration.baseType) &&
        Objects.equals(schemaLocation, priceAlteration.schemaLocation) &&
        Objects.equals(type, priceAlteration.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, applicationDuration, description, name, priceType, priority, recurringChargePeriod, unitOfMeasure, price, productOfferingPrice, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PriceAlteration {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    applicationDuration: ").append(toIndentedString(applicationDuration)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    priceType: ").append(toIndentedString(priceType)).append("\n");
    sb.append("    priority: ").append(toIndentedString(priority)).append("\n");
    sb.append("    recurringChargePeriod: ").append(toIndentedString(recurringChargePeriod)).append("\n");
    sb.append("    unitOfMeasure: ").append(toIndentedString(unitOfMeasure)).append("\n");
    sb.append("    price: ").append(toIndentedString(price)).append("\n");
    sb.append("    productOfferingPrice: ").append(toIndentedString(productOfferingPrice)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

