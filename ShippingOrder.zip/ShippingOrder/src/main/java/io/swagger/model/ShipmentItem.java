package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.model.Characteristic;
import io.swagger.model.ExternalIdentifier;
import io.swagger.model.Price;
import io.swagger.model.ProductRefOrValue;
import io.swagger.model.ProductStockRef;
import io.swagger.model.Quantity;
import io.swagger.model.ReserveProductStockRef;
import io.swagger.model.ShipmentItemActionType;
import java.util.List;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;


@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class ShipmentItem   {
  
  private String id = null;
  private String quantity = null;
  private String sku = null;
  private ShipmentItemActionType action = null;
  private List<Characteristic> characteristic = new ArrayList<Characteristic>();
  private List<ExternalIdentifier> externalIdentifier = new ArrayList<ExternalIdentifier>();
  private ProductRefOrValue product = null;
  private ReserveProductStockRef productReservationRef = null;
  private ProductStockRef productStockRef = null;
  private Price shipmentItemPrice = null;
  private Quantity weight = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Identifier of the individual shipment line item
   **/
  
  @ApiModelProperty(example = "4aafacbd-11ff-4dc8-b445-305f2215715f789", value = "Identifier of the individual shipment line item")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Quantity the individual shipment line item
   **/
  
  @ApiModelProperty(example = "10 units", value = "Quantity the individual shipment line item")
  @JsonProperty("quantity")
  public String getQuantity() {
    return quantity;
  }
  public void setQuantity(String quantity) {
    this.quantity = quantity;
  }

  /**
   * SKU (Stock Keeping Unit) is a unique code that you use to identify every inventory item in your warehouse
   **/
  
  @ApiModelProperty(example = "UGG-BB-PUR-06", value = "SKU (Stock Keeping Unit) is a unique code that you use to identify every inventory item in your warehouse")
  @JsonProperty("sku")
  public String getSku() {
    return sku;
  }
  public void setSku(String sku) {
    this.sku = sku;
  }

  /**
   * The action to be carried out on the shipment item. Can be: add, modify, delete, noChange
   **/
  
  @ApiModelProperty(value = "The action to be carried out on the shipment item. Can be: add, modify, delete, noChange")
  @JsonProperty("action")
  public ShipmentItemActionType getAction() {
    return action;
  }
  public void setAction(ShipmentItemActionType action) {
    this.action = action;
  }

  /**
   * List of characteristics with values that define the test run
   **/
  
  @ApiModelProperty(value = "List of characteristics with values that define the test run")
  @JsonProperty("characteristic")
  public List<Characteristic> getCharacteristic() {
    return characteristic;
  }
  public void setCharacteristic(List<Characteristic> characteristic) {
    this.characteristic = characteristic;
  }

  /**
   * An identification of an entity that is owned by or originates in a software system different from the current system, for example a ProductOrder handed off from a commerce platform into an order handling system. The structure identifies the system itself, the nature of the entity within the system (e.g. class name) and the unique ID of the entity within the system. It is anticipated that multiple external IDs can be held for a single entity, e.g. if the entity passed through multiple systems on the way to the current system. In this case the consumer is expected to sequence the IDs in the array in reverse order of provenance, i.e. most recent system first in the list.
   **/
  
  @ApiModelProperty(value = "An identification of an entity that is owned by or originates in a software system different from the current system, for example a ProductOrder handed off from a commerce platform into an order handling system. The structure identifies the system itself, the nature of the entity within the system (e.g. class name) and the unique ID of the entity within the system. It is anticipated that multiple external IDs can be held for a single entity, e.g. if the entity passed through multiple systems on the way to the current system. In this case the consumer is expected to sequence the IDs in the array in reverse order of provenance, i.e. most recent system first in the list.")
  @JsonProperty("externalIdentifier")
  public List<ExternalIdentifier> getExternalIdentifier() {
    return externalIdentifier;
  }
  public void setExternalIdentifier(List<ExternalIdentifier> externalIdentifier) {
    this.externalIdentifier = externalIdentifier;
  }

  /**
   * This data structure captures the product information.
   **/
  
  @ApiModelProperty(value = "This data structure captures the product information.")
  @JsonProperty("product")
  public ProductRefOrValue getProduct() {
    return product;
  }
  public void setProduct(ProductRefOrValue product) {
    this.product = product;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productReservationRef")
  public ReserveProductStockRef getProductReservationRef() {
    return productReservationRef;
  }
  public void setProductReservationRef(ReserveProductStockRef productReservationRef) {
    this.productReservationRef = productReservationRef;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productStockRef")
  public ProductStockRef getProductStockRef() {
    return productStockRef;
  }
  public void setProductStockRef(ProductStockRef productStockRef) {
    this.productStockRef = productStockRef;
  }

  /**
   * Item price details
   **/
  
  @ApiModelProperty(value = "Item price details")
  @JsonProperty("shipmentItemPrice")
  public Price getShipmentItemPrice() {
    return shipmentItemPrice;
  }
  public void setShipmentItemPrice(Price shipmentItemPrice) {
    this.shipmentItemPrice = shipmentItemPrice;
  }

  /**
   * Weight of the shipping item package/parcel
   **/
  
  @ApiModelProperty(value = "Weight of the shipping item package/parcel")
  @JsonProperty("weight")
  public Quantity getWeight() {
    return weight;
  }
  public void setWeight(Quantity weight) {
    this.weight = weight;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShipmentItem shipmentItem = (ShipmentItem) o;
    return Objects.equals(id, shipmentItem.id) &&
        Objects.equals(quantity, shipmentItem.quantity) &&
        Objects.equals(sku, shipmentItem.sku) &&
        Objects.equals(action, shipmentItem.action) &&
        Objects.equals(characteristic, shipmentItem.characteristic) &&
        Objects.equals(externalIdentifier, shipmentItem.externalIdentifier) &&
        Objects.equals(product, shipmentItem.product) &&
        Objects.equals(productReservationRef, shipmentItem.productReservationRef) &&
        Objects.equals(productStockRef, shipmentItem.productStockRef) &&
        Objects.equals(shipmentItemPrice, shipmentItem.shipmentItemPrice) &&
        Objects.equals(weight, shipmentItem.weight) &&
        Objects.equals(baseType, shipmentItem.baseType) &&
        Objects.equals(schemaLocation, shipmentItem.schemaLocation) &&
        Objects.equals(type, shipmentItem.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, quantity, sku, action, characteristic, externalIdentifier, product, productReservationRef, productStockRef, shipmentItemPrice, weight, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("    sku: ").append(toIndentedString(sku)).append("\n");
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    characteristic: ").append(toIndentedString(characteristic)).append("\n");
    sb.append("    externalIdentifier: ").append(toIndentedString(externalIdentifier)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    productReservationRef: ").append(toIndentedString(productReservationRef)).append("\n");
    sb.append("    productStockRef: ").append(toIndentedString(productStockRef)).append("\n");
    sb.append("    shipmentItemPrice: ").append(toIndentedString(shipmentItemPrice)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

