package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Characteristic;
import io.swagger.model.Note;
import io.swagger.model.ProductOfferingRef;
import io.swagger.model.ProductOrderRef;
import io.swagger.model.ProductPrice;
import io.swagger.model.RelatedPartyWithContactInfo;
import io.swagger.model.RelatedPlaceRefOrValue;
import io.swagger.model.RelatedShippingOrder;
import io.swagger.model.ShippingInstruction;
import io.swagger.model.ShippingOrderItem;
import java.util.Date;
import java.util.List;

import io.swagger.util.EntityCreator;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="A Shipping Order is a document used by a business to specify what items are to be transferred from a storage location or warehouse to which person and to which new location. A Shipping Order can typically be sent along with a shipment of goods so that the person receiving them can verify that the document correctly reflects the items that they actually received.")
@EntityCreator(value  ="ShippingOrderEntity",isSubEntity = false,propertyName = "")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class ShippingOrder   {
  
  private String id = null;
  private String href = null;
  private Date creationDate = null;
  private Date lastUpdateDate = null;
  private String status = null;
  private List<Note> note = new ArrayList<Note>();
  private RelatedPlaceRefOrValue placeFrom = null;
  private RelatedPlaceRefOrValue placeTo = null;
  private ProductOrderRef productOrder = null;
  private List<RelatedPartyWithContactInfo> relatedParty = new ArrayList<RelatedPartyWithContactInfo>();
  private RelatedShippingOrder relatedShippingOrder = null;
  private ShippingInstruction shippingInstruction = null;
  private List<Characteristic> shippingOrderCharacteristic = new ArrayList<Characteristic>();
  private List<ShippingOrderItem> shippingOrderItem = new ArrayList<ShippingOrderItem>();
  private ProductOfferingRef shippingOrderOffering = null;
  private ProductPrice shippingOrderPrice = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Identifier of the Shipping Order
   **/
  
  @ApiModelProperty(example = "4aafacbd-11ff-4dc8-b445-305f2215715f123", value = "Identifier of the Shipping Order")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Shipping Order unique reference
   **/
  
  @ApiModelProperty(example = "http://host/Attachment/4aafacbd-11ff-4dc8-b445-305f2215715f", value = "Shipping Order unique reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Date of the Shipping Order
   **/
  
  @ApiModelProperty(example = "2020-11-10T08:00:00Z", value = "Date of the Shipping Order")
  @JsonProperty("creationDate")
  public Date getCreationDate() {
    return creationDate;
  }
  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  /**
   * Date of the Shipping Order
   **/
  
  @ApiModelProperty(example = "2020-11-10T08:00:00Z", value = "Date of the Shipping Order")
  @JsonProperty("lastUpdateDate")
  public Date getLastUpdateDate() {
    return lastUpdateDate;
  }
  public void setLastUpdateDate(Date lastUpdateDate) {
    this.lastUpdateDate = lastUpdateDate;
  }

  /**
   * status of shipping order e.g \&quot;active\&quot; , \&quot;savedForLater\&quot;
   **/
  
  @ApiModelProperty(example = "active", value = "status of shipping order e.g \"active\" , \"savedForLater\"")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * A list of notes made on this shipping shipment
   **/
  
  @ApiModelProperty(value = "A list of notes made on this shipping shipment")
  @JsonProperty("note")
  public List<Note> getNote() {
    return note;
  }
  public void setNote(List<Note> note) {
    this.note = note;
  }

  /**
   * Source location of the item. E.g. warehouse or shop location. The location can be specified at the shipping order level or at the shipping order item level if multiple sources are specified part of the same shipping order.
   **/
  
  @ApiModelProperty(value = "Source location of the item. E.g. warehouse or shop location. The location can be specified at the shipping order level or at the shipping order item level if multiple sources are specified part of the same shipping order.")
  @JsonProperty("placeFrom")
  public RelatedPlaceRefOrValue getPlaceFrom() {
    return placeFrom;
  }
  public void setPlaceFrom(RelatedPlaceRefOrValue placeFrom) {
    this.placeFrom = placeFrom;
  }

  /**
   * Destination of the item. E.g. customer home address. The location can be specified at the shipping order level or at the shipping order item level if multiple destinations are specified part of the same shipping order.
   **/
  
  @ApiModelProperty(value = "Destination of the item. E.g. customer home address. The location can be specified at the shipping order level or at the shipping order item level if multiple destinations are specified part of the same shipping order.")
  @JsonProperty("placeTo")
  public RelatedPlaceRefOrValue getPlaceTo() {
    return placeTo;
  }
  public void setPlaceTo(RelatedPlaceRefOrValue placeTo) {
    this.placeTo = placeTo;
  }

  /**
   * The product order for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product order for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("productOrder")
  public ProductOrderRef getProductOrder() {
    return productOrder;
  }
  public void setProductOrder(ProductOrderRef productOrder) {
    this.productOrder = productOrder;
  }

  /**
   * An existing related party that has some form of correlation with the given shipping order. It can be recipient, payer, etc.
   **/
  
  @ApiModelProperty(value = "An existing related party that has some form of correlation with the given shipping order. It can be recipient, payer, etc.")
  @JsonProperty("relatedParty")
  public List<RelatedPartyWithContactInfo> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedPartyWithContactInfo> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * An existing shipping order that has some form of correlation with the given shipping order
   **/
  
  @ApiModelProperty(value = "An existing shipping order that has some form of correlation with the given shipping order")
  @JsonProperty("relatedShippingOrder")
  public RelatedShippingOrder getRelatedShippingOrder() {
    return relatedShippingOrder;
  }
  public void setRelatedShippingOrder(RelatedShippingOrder relatedShippingOrder) {
    this.relatedShippingOrder = relatedShippingOrder;
  }

  /**
   * The product order for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product order for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("shippingInstruction")
  public ShippingInstruction getShippingInstruction() {
    return shippingInstruction;
  }
  public void setShippingInstruction(ShippingInstruction shippingInstruction) {
    this.shippingInstruction = shippingInstruction;
  }

  /**
   * List of characteristics with values
   **/
  
  @ApiModelProperty(value = "List of characteristics with values")
  @JsonProperty("shippingOrderCharacteristic")
  public List<Characteristic> getShippingOrderCharacteristic() {
    return shippingOrderCharacteristic;
  }
  public void setShippingOrderCharacteristic(List<Characteristic> shippingOrderCharacteristic) {
    this.shippingOrderCharacteristic = shippingOrderCharacteristic;
  }

  /**
   * A list of shipping order items. Each shipping order item has a corresponding Shipment(e.g. parcel) which has one or multiple products in it
   **/
  
  @ApiModelProperty(value = "A list of shipping order items. Each shipping order item has a corresponding Shipment(e.g. parcel) which has one or multiple products in it")
  @JsonProperty("shippingOrderItem")
  public List<ShippingOrderItem> getShippingOrderItem() {
    return shippingOrderItem;
  }
  public void setShippingOrderItem(List<ShippingOrderItem> shippingOrderItem) {
    this.shippingOrderItem = shippingOrderItem;
  }

  /**
   * Shipping order can have a corresponding entry in the product catalog (product offering)
   **/
  
  @ApiModelProperty(value = "Shipping order can have a corresponding entry in the product catalog (product offering)")
  @JsonProperty("shippingOrderOffering")
  public ProductOfferingRef getShippingOrderOffering() {
    return shippingOrderOffering;
  }
  public void setShippingOrderOffering(ProductOfferingRef shippingOrderOffering) {
    this.shippingOrderOffering = shippingOrderOffering;
  }

  /**
   * Shipping Order price
   **/
  
  @ApiModelProperty(value = "Shipping Order price")
  @JsonProperty("shippingOrderPrice")
  public ProductPrice getShippingOrderPrice() {
    return shippingOrderPrice;
  }
  public void setShippingOrderPrice(ProductPrice shippingOrderPrice) {
    this.shippingOrderPrice = shippingOrderPrice;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingOrder shippingOrder = (ShippingOrder) o;
    return Objects.equals(id, shippingOrder.id) &&
        Objects.equals(href, shippingOrder.href) &&
        Objects.equals(creationDate, shippingOrder.creationDate) &&
        Objects.equals(lastUpdateDate, shippingOrder.lastUpdateDate) &&
        Objects.equals(status, shippingOrder.status) &&
        Objects.equals(note, shippingOrder.note) &&
        Objects.equals(placeFrom, shippingOrder.placeFrom) &&
        Objects.equals(placeTo, shippingOrder.placeTo) &&
        Objects.equals(productOrder, shippingOrder.productOrder) &&
        Objects.equals(relatedParty, shippingOrder.relatedParty) &&
        Objects.equals(relatedShippingOrder, shippingOrder.relatedShippingOrder) &&
        Objects.equals(shippingInstruction, shippingOrder.shippingInstruction) &&
        Objects.equals(shippingOrderCharacteristic, shippingOrder.shippingOrderCharacteristic) &&
        Objects.equals(shippingOrderItem, shippingOrder.shippingOrderItem) &&
        Objects.equals(shippingOrderOffering, shippingOrder.shippingOrderOffering) &&
        Objects.equals(shippingOrderPrice, shippingOrder.shippingOrderPrice) &&
        Objects.equals(baseType, shippingOrder.baseType) &&
        Objects.equals(schemaLocation, shippingOrder.schemaLocation) &&
        Objects.equals(type, shippingOrder.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, creationDate, lastUpdateDate, status, note, placeFrom, placeTo, productOrder, relatedParty, relatedShippingOrder, shippingInstruction, shippingOrderCharacteristic, shippingOrderItem, shippingOrderOffering, shippingOrderPrice, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingOrder {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    creationDate: ").append(toIndentedString(creationDate)).append("\n");
    sb.append("    lastUpdateDate: ").append(toIndentedString(lastUpdateDate)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    placeFrom: ").append(toIndentedString(placeFrom)).append("\n");
    sb.append("    placeTo: ").append(toIndentedString(placeTo)).append("\n");
    sb.append("    productOrder: ").append(toIndentedString(productOrder)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    relatedShippingOrder: ").append(toIndentedString(relatedShippingOrder)).append("\n");
    sb.append("    shippingInstruction: ").append(toIndentedString(shippingInstruction)).append("\n");
    sb.append("    shippingOrderCharacteristic: ").append(toIndentedString(shippingOrderCharacteristic)).append("\n");
    sb.append("    shippingOrderItem: ").append(toIndentedString(shippingOrderItem)).append("\n");
    sb.append("    shippingOrderOffering: ").append(toIndentedString(shippingOrderOffering)).append("\n");
    sb.append("    shippingOrderPrice: ").append(toIndentedString(shippingOrderPrice)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

