package io.swagger.util;

import java.util.List;

public record ApiMethodProps(
    String path, ApiOperationProps operation, List<ApiResponseProps> responses) {}
