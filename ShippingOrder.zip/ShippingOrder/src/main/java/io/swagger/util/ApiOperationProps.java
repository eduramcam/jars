package io.swagger.util;

public record ApiOperationProps(String value, String note, String response, String method) {}
