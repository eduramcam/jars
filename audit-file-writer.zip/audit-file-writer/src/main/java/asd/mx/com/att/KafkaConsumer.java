package asd.mx.com.att;


import com.fasterxml.jackson.databind.ObjectMapper;
import io.vertx.core.eventbus.EventBus;
import jakarta.enterprise.context.ApplicationScoped;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.eclipse.microprofile.reactive.messaging.Incoming;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ApplicationScoped
public class KafkaConsumer {

    public static final Logger log = LoggerFactory.getLogger(KafkaConsumer.class);
    private final ObjectMapper objectMapper;
    private final EventBus eventBus;


    public KafkaConsumer(ObjectMapper objectMapper, EventBus eventBus) {
        this.objectMapper = objectMapper;
        this.eventBus = eventBus;
    }

    @Incoming("product-orders")
    public void ordersConsumer(ConsumerRecord<String, String> consumerRecord) {
        try {
            System.out.println("Consumed record" + consumerRecord.value());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
