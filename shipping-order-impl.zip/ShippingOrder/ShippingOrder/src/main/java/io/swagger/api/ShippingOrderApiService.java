package io.swagger.api;


import com.comviva.pacs.exceptions.NotFoundException;
import io.swagger.model.ShippingOrderCreate;
import io.swagger.model.ShippingOrderUpdate;

import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public interface ShippingOrderApiService {
      Response createShippingOrder(ShippingOrderCreate shippingOrder,SecurityContext securityContext)
      throws NotFoundException;
      Response listShippingOrder(String fields,Integer offset,Integer limit,SecurityContext securityContext)
      throws NotFoundException;
      Response patchShippingOrder(String id,ShippingOrderUpdate shippingOrder,SecurityContext securityContext)
      throws NotFoundException;
      Response retrieveShippingOrder(String id,String fields,SecurityContext securityContext)
      throws NotFoundException;
      Response updateShippingOrder(String id,ShippingOrderUpdate shippingOrder,SecurityContext securityContext)
      throws NotFoundException;
}
