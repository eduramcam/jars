package io.swagger.model;

import io.swagger.util.ModelExtender;

@ModelExtender(value = ShippingOrder.class)
public interface ExtenderHelper {
}
