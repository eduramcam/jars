package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import io.swagger.annotations.ApiModel;
import com.fasterxml.jackson.annotation.JsonValue;
import jakarta.validation.constraints.*;
public enum ShipmentItemActionType {
    add, modify, delete, noChange
}
