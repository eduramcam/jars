package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.Characteristic;
import io.swagger.model.Money;
import io.swagger.model.Note;
import io.swagger.model.SignatureRequiredByType;
import io.swagger.model.TimePeriod;
import java.util.List;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="Instructions and details for the carrier")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class ShippingInstruction   {
  
  private String id = null;
  private String href = null;
  private String carrierId = null;
  private String carrierName = null;
  private String carrierServiceCode = null;
  private Integer deliveryAttempts = null;
  private String deliverySpeed = null;
  private String labelMessage = null;
  private String packageType = null;
  private String receiptConfirmation = null;
  private String shippingType = null;
  private Boolean signatureRequired = null;
  private String warehouseId = null;
  private TimePeriod deliveryTimeSlot = null;
  private List<Characteristic> instructionCharacteristic = new ArrayList<Characteristic>();
  private Money insuredValue = null;
  private List<Note> note = new ArrayList<Note>();
  private SignatureRequiredByType signatureRequiredBy = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * The carrier identifier
   **/
  
  @ApiModelProperty(example = "1010123", value = "The carrier identifier")
  @JsonProperty("carrierId")
  public String getCarrierId() {
    return carrierId;
  }
  public void setCarrierId(String carrierId) {
    this.carrierId = carrierId;
  }

  /**
   * The carrier name
   **/
  
  @ApiModelProperty(example = "On Time Deliveries Ltd", value = "The carrier name")
  @JsonProperty("carrierName")
  public String getCarrierName() {
    return carrierName;
  }
  public void setCarrierName(String carrierName) {
    this.carrierName = carrierName;
  }

  /**
   * The service code used by the carrier to ship the package, royal mail ground, royal mail first class, etc
   **/
  
  @ApiModelProperty(example = "XH545554533GB", value = "The service code used by the carrier to ship the package, royal mail ground, royal mail first class, etc")
  @JsonProperty("carrierServiceCode")
  public String getCarrierServiceCode() {
    return carrierServiceCode;
  }
  public void setCarrierServiceCode(String carrierServiceCode) {
    this.carrierServiceCode = carrierServiceCode;
  }

  /**
   * Shipping delivery attempts that should be performed
   **/
  
  @ApiModelProperty(example = "3", value = "Shipping delivery attempts that should be performed")
  @JsonProperty("deliveryAttempts")
  public Integer getDeliveryAttempts() {
    return deliveryAttempts;
  }
  public void setDeliveryAttempts(Integer deliveryAttempts) {
    this.deliveryAttempts = deliveryAttempts;
  }

  /**
   * Shipping delivery speed, same day, next day, next business day, etc
   **/
  
  @ApiModelProperty(example = "SameDay", value = "Shipping delivery speed, same day, next day, next business day, etc")
  @JsonProperty("deliverySpeed")
  public String getDeliverySpeed() {
    return deliverySpeed;
  }
  public void setDeliverySpeed(String deliverySpeed) {
    this.deliverySpeed = deliverySpeed;
  }

  /**
   * Shipping delivery message label
   **/
  
  @ApiModelProperty(example = "FAO Ink Industries", value = "Shipping delivery message label")
  @JsonProperty("labelMessage")
  public String getLabelMessage() {
    return labelMessage;
  }
  public void setLabelMessage(String labelMessage) {
    this.labelMessage = labelMessage;
  }

  /**
   * The type of packaging
   **/
  
  @ApiModelProperty(example = "Bottle, gas", value = "The type of packaging")
  @JsonProperty("packageType")
  public String getPackageType() {
    return packageType;
  }
  public void setPackageType(String packageType) {
    this.packageType = packageType;
  }

  /**
   * Delivery confirmation required for the shipment (none, signature, over18Signature)
   **/
  
  @ApiModelProperty(example = "signature", value = "Delivery confirmation required for the shipment (none, signature, over18Signature)")
  @JsonProperty("receiptConfirmation")
  public String getReceiptConfirmation() {
    return receiptConfirmation;
  }
  public void setReceiptConfirmation(String receiptConfirmation) {
    this.receiptConfirmation = receiptConfirmation;
  }

  /**
   * The shipping type, e.g. thick_envelope, small_flat_rate_box, large_package, etc.
   **/
  
  @ApiModelProperty(example = "large_package", value = "The shipping type, e.g. thick_envelope, small_flat_rate_box, large_package, etc.")
  @JsonProperty("shippingType")
  public String getShippingType() {
    return shippingType;
  }
  public void setShippingType(String shippingType) {
    this.shippingType = shippingType;
  }

  /**
   **/
  
  @ApiModelProperty(example = "true", value = "")
  @JsonProperty("signatureRequired")
  public Boolean isSignatureRequired() {
    return signatureRequired;
  }
  public void setSignatureRequired(Boolean signatureRequired) {
    this.signatureRequired = signatureRequired;
  }

  /**
   * The identification of the warehouse that the shipment is being shipped from.
   **/
  
  @ApiModelProperty(example = "wh12345", value = "The identification of the warehouse that the shipment is being shipped from.")
  @JsonProperty("warehouseId")
  public String getWarehouseId() {
    return warehouseId;
  }
  public void setWarehouseId(String warehouseId) {
    this.warehouseId = warehouseId;
  }

  /**
   * Shipping delivery time slot
   **/
  
  @ApiModelProperty(value = "Shipping delivery time slot")
  @JsonProperty("deliveryTimeSlot")
  public TimePeriod getDeliveryTimeSlot() {
    return deliveryTimeSlot;
  }
  public void setDeliveryTimeSlot(TimePeriod deliveryTimeSlot) {
    this.deliveryTimeSlot = deliveryTimeSlot;
  }

  /**
   * Additional shipping characteristics that maybe specific to one or another carrier
   **/
  
  @ApiModelProperty(value = "Additional shipping characteristics that maybe specific to one or another carrier")
  @JsonProperty("instructionCharacteristic")
  public List<Characteristic> getInstructionCharacteristic() {
    return instructionCharacteristic;
  }
  public void setInstructionCharacteristic(List<Characteristic> instructionCharacteristic) {
    this.instructionCharacteristic = instructionCharacteristic;
  }

  /**
   * Shipping delivery value
   **/
  
  @ApiModelProperty(value = "Shipping delivery value")
  @JsonProperty("insuredValue")
  public Money getInsuredValue() {
    return insuredValue;
  }
  public void setInsuredValue(Money insuredValue) {
    this.insuredValue = insuredValue;
  }

  /**
   * A list of notes made on this shipment item
   **/
  
  @ApiModelProperty(value = "A list of notes made on this shipment item")
  @JsonProperty("note")
  public List<Note> getNote() {
    return note;
  }
  public void setNote(List<Note> note) {
    this.note = note;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("signatureRequiredBy")
  public SignatureRequiredByType getSignatureRequiredBy() {
    return signatureRequiredBy;
  }
  public void setSignatureRequiredBy(SignatureRequiredByType signatureRequiredBy) {
    this.signatureRequiredBy = signatureRequiredBy;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingInstruction shippingInstruction = (ShippingInstruction) o;
    return Objects.equals(id, shippingInstruction.id) &&
        Objects.equals(href, shippingInstruction.href) &&
        Objects.equals(carrierId, shippingInstruction.carrierId) &&
        Objects.equals(carrierName, shippingInstruction.carrierName) &&
        Objects.equals(carrierServiceCode, shippingInstruction.carrierServiceCode) &&
        Objects.equals(deliveryAttempts, shippingInstruction.deliveryAttempts) &&
        Objects.equals(deliverySpeed, shippingInstruction.deliverySpeed) &&
        Objects.equals(labelMessage, shippingInstruction.labelMessage) &&
        Objects.equals(packageType, shippingInstruction.packageType) &&
        Objects.equals(receiptConfirmation, shippingInstruction.receiptConfirmation) &&
        Objects.equals(shippingType, shippingInstruction.shippingType) &&
        Objects.equals(signatureRequired, shippingInstruction.signatureRequired) &&
        Objects.equals(warehouseId, shippingInstruction.warehouseId) &&
        Objects.equals(deliveryTimeSlot, shippingInstruction.deliveryTimeSlot) &&
        Objects.equals(instructionCharacteristic, shippingInstruction.instructionCharacteristic) &&
        Objects.equals(insuredValue, shippingInstruction.insuredValue) &&
        Objects.equals(note, shippingInstruction.note) &&
        Objects.equals(signatureRequiredBy, shippingInstruction.signatureRequiredBy) &&
        Objects.equals(baseType, shippingInstruction.baseType) &&
        Objects.equals(schemaLocation, shippingInstruction.schemaLocation) &&
        Objects.equals(type, shippingInstruction.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, carrierId, carrierName, carrierServiceCode, deliveryAttempts, deliverySpeed, labelMessage, packageType, receiptConfirmation, shippingType, signatureRequired, warehouseId, deliveryTimeSlot, instructionCharacteristic, insuredValue, note, signatureRequiredBy, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingInstruction {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    carrierId: ").append(toIndentedString(carrierId)).append("\n");
    sb.append("    carrierName: ").append(toIndentedString(carrierName)).append("\n");
    sb.append("    carrierServiceCode: ").append(toIndentedString(carrierServiceCode)).append("\n");
    sb.append("    deliveryAttempts: ").append(toIndentedString(deliveryAttempts)).append("\n");
    sb.append("    deliverySpeed: ").append(toIndentedString(deliverySpeed)).append("\n");
    sb.append("    labelMessage: ").append(toIndentedString(labelMessage)).append("\n");
    sb.append("    packageType: ").append(toIndentedString(packageType)).append("\n");
    sb.append("    receiptConfirmation: ").append(toIndentedString(receiptConfirmation)).append("\n");
    sb.append("    shippingType: ").append(toIndentedString(shippingType)).append("\n");
    sb.append("    signatureRequired: ").append(toIndentedString(signatureRequired)).append("\n");
    sb.append("    warehouseId: ").append(toIndentedString(warehouseId)).append("\n");
    sb.append("    deliveryTimeSlot: ").append(toIndentedString(deliveryTimeSlot)).append("\n");
    sb.append("    instructionCharacteristic: ").append(toIndentedString(instructionCharacteristic)).append("\n");
    sb.append("    insuredValue: ").append(toIndentedString(insuredValue)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    signatureRequiredBy: ").append(toIndentedString(signatureRequiredBy)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

