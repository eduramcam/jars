package io.swagger.model;

import java.util.Objects;
import java.util.ArrayList;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.model.ProductOfferingRef;
import io.swagger.model.ProductOrderItemRef;
import io.swagger.model.ProductPrice;
import io.swagger.model.ProductRef;
import io.swagger.model.RelatedPartyWithContactInfo;
import io.swagger.model.RelatedPlaceRefOrValue;
import io.swagger.model.ShipmentRefOrValue;
import io.swagger.model.ShippingInstruction;
import io.swagger.model.ShippingOrderItemActionType;
import java.util.List;
import jakarta.validation.constraints.*;
import io.swagger.annotations.*;

@ApiModel(description="A list of shipping order items")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-22T18:51:35.922Z")
public class ShippingOrderItem   {
  
  private String id = null;
  private String href = null;
  private String quantity = null;
  private String status = null;
  private ShippingOrderItemActionType action = null;
  private RelatedPlaceRefOrValue placeFrom = null;
  private RelatedPlaceRefOrValue placeTo = null;
  private ProductRef product = null;
  private ProductOfferingRef productOffering = null;
  private ProductOrderItemRef productOrderItem = null;
  private List<RelatedPartyWithContactInfo> relatedParty = new ArrayList<RelatedPartyWithContactInfo>();
  private ShipmentRefOrValue shipment = null;
  private ShippingInstruction shippingInstruction = null;
  private ProductOfferingRef shippingOrderItemOffering = null;
  private ProductPrice shippingOrderItemPrice = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Identifier of the Shipping Order Item
   **/
  
  @ApiModelProperty(example = "4aafacbd-11ff-4dc8-b445-305f2215715f", required = true, value = "Identifier of the Shipping Order Item")
  @JsonProperty("id")
  @NotNull
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Quantity the individual shipment line item
   **/
  
  @ApiModelProperty(example = "10 units", value = "Quantity the individual shipment line item")
  @JsonProperty("quantity")
  public String getQuantity() {
    return quantity;
  }
  public void setQuantity(String quantity) {
    this.quantity = quantity;
  }

  /**
   * status of shipping order item. e.g \&quot;active\&quot; , \&quot;savedForLater\&quot;
   **/
  
  @ApiModelProperty(example = "active", value = "status of shipping order item. e.g \"active\" , \"savedForLater\"")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * The action to be carried out on the Product. Can be: add, modify, delete, noChange
   **/
  
  @ApiModelProperty(required = true, value = "The action to be carried out on the Product. Can be: add, modify, delete, noChange")
  @JsonProperty("action")
  @NotNull
  public ShippingOrderItemActionType getAction() {
    return action;
  }
  public void setAction(ShippingOrderItemActionType action) {
    this.action = action;
  }

  /**
   * Source location of the item. E.g. warehouse or shop location
   **/
  
  @ApiModelProperty(value = "Source location of the item. E.g. warehouse or shop location")
  @JsonProperty("placeFrom")
  public RelatedPlaceRefOrValue getPlaceFrom() {
    return placeFrom;
  }
  public void setPlaceFrom(RelatedPlaceRefOrValue placeFrom) {
    this.placeFrom = placeFrom;
  }

  /**
   * Destination of the item. E.g. customer home address. 
   **/
  
  @ApiModelProperty(value = "Destination of the item. E.g. customer home address. ")
  @JsonProperty("placeTo")
  public RelatedPlaceRefOrValue getPlaceTo() {
    return placeTo;
  }
  public void setPlaceTo(RelatedPlaceRefOrValue placeTo) {
    this.placeTo = placeTo;
  }

  /**
   * The product for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("product")
  public ProductRef getProduct() {
    return product;
  }
  public void setProduct(ProductRef product) {
    this.product = product;
  }

  /**
   * Item has a corresponding offering in the product catalog.
   **/
  
  @ApiModelProperty(value = "Item has a corresponding offering in the product catalog.")
  @JsonProperty("productOffering")
  public ProductOfferingRef getProductOffering() {
    return productOffering;
  }
  public void setProductOffering(ProductOfferingRef productOffering) {
    this.productOffering = productOffering;
  }

  /**
   * The product order item for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product order item for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("productOrderItem")
  public ProductOrderItemRef getProductOrderItem() {
    return productOrderItem;
  }
  public void setProductOrderItem(ProductOrderItemRef productOrderItem) {
    this.productOrderItem = productOrderItem;
  }

  /**
   * A party which is involved in this shipment and the role they are playing and address. In case of shipping to addresses where a geo location is needed than then PlaceTo,PlaceFrom can be used.
   **/
  
  @ApiModelProperty(value = "A party which is involved in this shipment and the role they are playing and address. In case of shipping to addresses where a geo location is needed than then PlaceTo,PlaceFrom can be used.")
  @JsonProperty("relatedParty")
  public List<RelatedPartyWithContactInfo> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedPartyWithContactInfo> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * A set of goods to be shipped
   **/
  
  @ApiModelProperty(value = "A set of goods to be shipped")
  @JsonProperty("shipment")
  public ShipmentRefOrValue getShipment() {
    return shipment;
  }
  public void setShipment(ShipmentRefOrValue shipment) {
    this.shipment = shipment;
  }

  /**
   * Shipping instructions, usually relevant for the carrier.
   **/
  
  @ApiModelProperty(value = "Shipping instructions, usually relevant for the carrier.")
  @JsonProperty("shippingInstruction")
  public ShippingInstruction getShippingInstruction() {
    return shippingInstruction;
  }
  public void setShippingInstruction(ShippingInstruction shippingInstruction) {
    this.shippingInstruction = shippingInstruction;
  }

  /**
   * Each shipping order item can have a corresponding product offer in the product catalog.
   **/
  
  @ApiModelProperty(value = "Each shipping order item can have a corresponding product offer in the product catalog.")
  @JsonProperty("shippingOrderItemOffering")
  public ProductOfferingRef getShippingOrderItemOffering() {
    return shippingOrderItemOffering;
  }
  public void setShippingOrderItemOffering(ProductOfferingRef shippingOrderItemOffering) {
    this.shippingOrderItemOffering = shippingOrderItemOffering;
  }

  /**
   * Shipping Order Item price. The price of shipping this item. It depends if there is a ShippingOrder level price or per each individual item.
   **/
  
  @ApiModelProperty(value = "Shipping Order Item price. The price of shipping this item. It depends if there is a ShippingOrder level price or per each individual item.")
  @JsonProperty("shippingOrderItemPrice")
  public ProductPrice getShippingOrderItemPrice() {
    return shippingOrderItemPrice;
  }
  public void setShippingOrderItemPrice(ProductPrice shippingOrderItemPrice) {
    this.shippingOrderItemPrice = shippingOrderItemPrice;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingOrderItem shippingOrderItem = (ShippingOrderItem) o;
    return Objects.equals(id, shippingOrderItem.id) &&
        Objects.equals(href, shippingOrderItem.href) &&
        Objects.equals(quantity, shippingOrderItem.quantity) &&
        Objects.equals(status, shippingOrderItem.status) &&
        Objects.equals(action, shippingOrderItem.action) &&
        Objects.equals(placeFrom, shippingOrderItem.placeFrom) &&
        Objects.equals(placeTo, shippingOrderItem.placeTo) &&
        Objects.equals(product, shippingOrderItem.product) &&
        Objects.equals(productOffering, shippingOrderItem.productOffering) &&
        Objects.equals(productOrderItem, shippingOrderItem.productOrderItem) &&
        Objects.equals(relatedParty, shippingOrderItem.relatedParty) &&
        Objects.equals(shipment, shippingOrderItem.shipment) &&
        Objects.equals(shippingInstruction, shippingOrderItem.shippingInstruction) &&
        Objects.equals(shippingOrderItemOffering, shippingOrderItem.shippingOrderItemOffering) &&
        Objects.equals(shippingOrderItemPrice, shippingOrderItem.shippingOrderItemPrice) &&
        Objects.equals(baseType, shippingOrderItem.baseType) &&
        Objects.equals(schemaLocation, shippingOrderItem.schemaLocation) &&
        Objects.equals(type, shippingOrderItem.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, quantity, status, action, placeFrom, placeTo, product, productOffering, productOrderItem, relatedParty, shipment, shippingInstruction, shippingOrderItemOffering, shippingOrderItemPrice, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingOrderItem {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    quantity: ").append(toIndentedString(quantity)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    action: ").append(toIndentedString(action)).append("\n");
    sb.append("    placeFrom: ").append(toIndentedString(placeFrom)).append("\n");
    sb.append("    placeTo: ").append(toIndentedString(placeTo)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    productOffering: ").append(toIndentedString(productOffering)).append("\n");
    sb.append("    productOrderItem: ").append(toIndentedString(productOrderItem)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    shipment: ").append(toIndentedString(shipment)).append("\n");
    sb.append("    shippingInstruction: ").append(toIndentedString(shippingInstruction)).append("\n");
    sb.append("    shippingOrderItemOffering: ").append(toIndentedString(shippingOrderItemOffering)).append("\n");
    sb.append("    shippingOrderItemPrice: ").append(toIndentedString(shippingOrderItemPrice)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

