package io.swagger.util;

import java.util.List;

public record ApiProps(
    String title, String basePath, String producer, String consumer, List<String> tags) {}
;
