package io.swagger.util;

public record ApiResponseProps(String code, String message, String responseClass,String responseContainer) {}
