package mx.com.att.asd.shippingOrder.impl.mappers;

import mx.com.att.asd.shippingOrder.entities.ShippingOrderEntity;
import mx.com.att.asd.shippingOrder.mappers.ShippingOrderMapperBase;
import mx.com.att.asd.shippingOrder.model.ShippingOrder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "cdi")
public interface ShippingOrderMapper extends ShippingOrderMapperBase {


    @Mappings({@Mapping(
            source = "placeFromId",
            target = "placeFrom.id"
    ), @Mapping(
            source = "placeFromHref",
            target = "placeFrom.href"
    ), @Mapping(
            source = "placeFromName",
            target = "placeFrom.name"
    ), @Mapping(
            source = "placeFromRole",
            target = "placeFrom.role"
    ), @Mapping(
            source = "placeFromBaseType",
            target = "placeFrom.baseType"
    ), @Mapping(
            source = "placeFromSchemaLocation",
            target = "placeFrom.schemaLocation"
    ), @Mapping(
            source = "placeFromType",
            target = "placeFrom.type"
    ), @Mapping(
            source = "placeFromReferredType",
            target = "placeFrom.referredType"
    ), @Mapping(
            source = "placeToId",
            target = "placeTo.id"
    ), @Mapping(
            source = "placeToHref",
            target = "placeTo.href"
    ), @Mapping(
            source = "placeToName",
            target = "placeTo.name"
    ), @Mapping(
            source = "placeToRole",
            target = "placeTo.role"
    ), @Mapping(
            source = "placeToBaseType",
            target = "placeTo.baseType"
    ), @Mapping(
            source = "placeToSchemaLocation",
            target = "placeTo.schemaLocation"
    ), @Mapping(
            source = "placeToType",
            target = "placeTo.type"
    ), @Mapping(
            source = "placeToReferredType",
            target = "placeTo.referredType"
    ), @Mapping(
            source = "productOrderId",
            target = "productOrder.id"
    ), @Mapping(
            source = "productOrderHref",
            target = "productOrder.href"
    ), @Mapping(
            source = "productOrderName",
            target = "productOrder.name"
    ), @Mapping(
            source = "productOrderBaseType",
            target = "productOrder.baseType"
    ), @Mapping(
            source = "productOrderSchemaLocation",
            target = "productOrder.schemaLocation"
    ), @Mapping(
            source = "productOrderType",
            target = "productOrder.type"
    ), @Mapping(
            source = "productOrderReferredType",
            target = "productOrder.referredType"
    ), @Mapping(
            source = "relatedShippingOrderId",
            target = "relatedShippingOrder.id"
    ), @Mapping(
            source = "relatedShippingOrderHref",
            target = "relatedShippingOrder.href"
    ), @Mapping(
            source = "relatedShippingOrderName",
            target = "relatedShippingOrder.name"
    ), @Mapping(
            source = "relatedShippingOrderRole",
            target = "relatedShippingOrder.role"
    ), @Mapping(
            source = "relatedShippingOrderBaseType",
            target = "relatedShippingOrder.baseType"
    ), @Mapping(
            source = "relatedShippingOrderSchemaLocation",
            target = "relatedShippingOrder.schemaLocation"
    ), @Mapping(
            source = "relatedShippingOrderType",
            target = "relatedShippingOrder.type"
    ), @Mapping(
            source = "relatedShippingOrderReferredType",
            target = "relatedShippingOrder.referredType"
    ), @Mapping(
            source = "shippingInstructionId",
            target = "shippingInstruction.id"
    ), @Mapping(
            source = "shippingInstructionHref",
            target = "shippingInstruction.href"
    ), @Mapping(
            source = "shippingInstructionCarrierId",
            target = "shippingInstruction.carrierId"
    ), @Mapping(
            source = "shippingInstructionCarrierName",
            target = "shippingInstruction.carrierName"
    ), @Mapping(
            source = "shippingInstructionCarrierServiceCode",
            target = "shippingInstruction.carrierServiceCode"
    ), @Mapping(
            source = "shippingInstructionDeliveryAttempts",
            target = "shippingInstruction.deliveryAttempts"
    ), @Mapping(
            source = "shippingInstructionDeliverySpeed",
            target = "shippingInstruction.deliverySpeed"
    ), @Mapping(
            source = "shippingInstructionLabelMessage",
            target = "shippingInstruction.labelMessage"
    ), @Mapping(
            source = "shippingInstructionPackageType",
            target = "shippingInstruction.packageType"
    ), @Mapping(
            source = "shippingInstructionReceiptConfirmation",
            target = "shippingInstruction.receiptConfirmation"
    ), @Mapping(
            source = "shippingInstructionShippingType",
            target = "shippingInstruction.shippingType"
    ), @Mapping(
            source = "shippingInstructionSignatureRequired",
            target = "shippingInstruction.signatureRequired"
    ), @Mapping(
            source = "shippingInstructionWarehouseId",
            target = "shippingInstruction.warehouseId"
    ), @Mapping(
            source = "shippingInstructiondeliveryTimeSlotEndDateTime",
            target = "shippingInstruction.deliveryTimeSlot.endDateTime"
    ), @Mapping(
            source = "shippingInstructiondeliveryTimeSlotStartDateTime",
            target = "shippingInstruction.deliveryTimeSlot.startDateTime"
    ), @Mapping(
            source = "shippingInstructioninsuredValueUnit",
            target = "shippingInstruction.insuredValue.unit"
    ), @Mapping(
            source = "shippingInstructioninsuredValueValue",
            target = "shippingInstruction.insuredValue.value"
    ), @Mapping(
            source = "shippingInstructionBaseType",
            target = "shippingInstruction.baseType"
    ), @Mapping(
            source = "shippingInstructionSchemaLocation",
            target = "shippingInstruction.schemaLocation"
    ), @Mapping(
            source = "shippingInstructionType",
            target = "shippingInstruction.type"
    ), @Mapping(
            source = "shippingOrderOfferingId",
            target = "shippingOrderOffering.id"
    ), @Mapping(
            source = "shippingOrderOfferingHref",
            target = "shippingOrderOffering.href"
    ), @Mapping(
            source = "shippingOrderOfferingName",
            target = "shippingOrderOffering.name"
    ), @Mapping(
            source = "shippingOrderOfferingBaseType",
            target = "shippingOrderOffering.baseType"
    ), @Mapping(
            source = "shippingOrderOfferingSchemaLocation",
            target = "shippingOrderOffering.schemaLocation"
    ), @Mapping(
            source = "shippingOrderOfferingType",
            target = "shippingOrderOffering.type"
    ), @Mapping(
            source = "shippingOrderOfferingReferredType",
            target = "shippingOrderOffering.referredType"
    )})
    ShippingOrder entityToModel(ShippingOrderEntity entity);

}
