package mx.com.att.asd.shippingOrder.impl.resources;

import io.vertx.core.eventbus.EventBus;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import lombok.extern.slf4j.Slf4j;
import mx.com.att.asd.shippingOrder.impl.services.ShippingOrderService;
import mx.com.att.asd.shippingOrder.model.ShippingOrder;


@Path("/api/v1/shippingOrders")
@Produces({"application/json;charset=utf-8"})
@Slf4j
public class ShippingOrderResource {
    private final ShippingOrderService service;
    private final EventBus eventBus;

    public ShippingOrderResource(ShippingOrderService service, EventBus eventBus) {
        this.service = service;
        this.eventBus = eventBus;
    }

    /**
     * This method creates a new shipping order
     *
     * @param shippingOrder
     * @param fields
     * @param uriInfo
     * @return Response with http status code 201 (created) and shippingOrder in response body
     */
    @POST
    public Response createShippingOrder(ShippingOrder shippingOrder,
                                        @QueryParam("fields") String fields,
                                        @Context UriInfo uriInfo) {
        var response = service.createShippingOrder(shippingOrder, fields, uriInfo);
        if (response.getStatus() < 300) {
            try {
                log.info("createShippingOrder completed successfully. Going to dispatch event");
                eventBus.publish("ShippingOrderCreateEvent", response.getEntity());
            } catch (Exception e) {
                log.error("Exception while sending kafka event ", e);
            }
        }
        return response;
    }

    /**
     * Get list of shippingOrders
     * We can use `offset` and `limit` query parameters to use pagination
     * Query parameter `sort` can be used to sort the response based on any fields of shipping order
     * We can select the fields to be returned in the response by providing a comma separated list of fields in
     * fields query parameter
     * Search filters can be provided as query parameter in the form of <fieldName>=<fieldValue>
     *
     * @param fields
     * @param offset
     * @param limit
     * @param uriInfo
     * @return List of ShippingOrders
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getShippingOrders(@QueryParam("fields") String fields,
                                      @QueryParam("offset") Integer offset,
                                      @QueryParam("limit") Integer limit,
                                      @Context UriInfo uriInfo) {
        log.info("Fetching shipping orders");
        return service.searchShippingOrders(fields, offset, limit, uriInfo);
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getShippingOrderById(@PathParam("id") String id) {
        log.info("Get shipping order by id {}", id);
        return service.getShippingOrderById(id);
    }

}
