package mx.com.att.asd.shippingOrder.impl.services;

import com.comviva.pacs.exceptions.NotFoundException;
import com.comviva.pacs.query.AggregateBuilder;
import com.comviva.pacs.query.ControllerHelper;
import com.comviva.pacs.query.GetRequestWrapper;
import com.comviva.pacs.query.TypedQueryBuilder;
import com.comviva.pacs.query.ValueObjectBuilder;
import com.google.common.reflect.TypeToken;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import lombok.extern.slf4j.Slf4j;
import mx.com.att.asd.shippingOrder.entities.ShippingOrderEntity;
import mx.com.att.asd.shippingOrder.impl.mappers.ShippingOrderMapper;
import mx.com.att.asd.shippingOrder.model.RelatedPlaceRefOrValue;
import mx.com.att.asd.shippingOrder.model.ShippingOrder;
import mx.com.att.asd.shippingOrder.model.ShippingOrderExtender;

import java.util.Date;
import java.util.Set;
import java.util.UUID;

@ApplicationScoped
@Slf4j
public class ShippingOrderService {
    private final ShippingOrderMapper mapper;
    private final TypedQueryBuilder<ShippingOrderEntity, ShippingOrder> queryBuilder;

    public ShippingOrderService(ShippingOrderMapper mapper) {
        this.mapper = mapper;

        var placeFrom = ValueObjectBuilder.aValueObject()
                .withName("placeFrom")
                .withValueObjectType(RelatedPlaceRefOrValue.class)
                .withJpaEntityType(ShippingOrderEntity.class)
                .withFieldConverter("id", "placeFromId")
                .withFieldConverter("name", "placeFromName")
                .withFieldConverter("role", "placeFromRole")
                .withFieldConverter("referredType", "placeFromReferredType")
                .build();
        var placeTo = ValueObjectBuilder.aValueObject()
                .withName("placeTo")
                .withValueObjectType(RelatedPlaceRefOrValue.class)
                .withJpaEntityType(ShippingOrderEntity.class)
                .withFieldConverter("id", "placeToId")
                .withFieldConverter("name", "placeToName")
                .withFieldConverter("role", "placeToRole")
                .withFieldConverter("referredType", "placeToReferredType")
                .build();
        var aggregate = AggregateBuilder.anAggregate()
                .withName("shippingOrder")
                .withJpaEntity(ShippingOrderEntity.class)
                .withChild("placeFrom", placeFrom)
                .withChild("placeTo", placeTo)
                .build();
        TypeToken<ShippingOrderEntity> typeToken = new TypeToken<>() {
        };
        var extender = new ShippingOrderExtender();
        this.queryBuilder = new TypedQueryBuilder<>(aggregate,
                typeToken,
                mapper::entityToModel,
                extender::cloneWithAllowedFields);
    }

    @Transactional
    public Response createShippingOrder(ShippingOrder shippingOrder,
                                        @QueryParam("fields") String fields,
                                        @Context UriInfo uriInfo) {
        log.info("Creating shipping order...");
        shippingOrder.setId(UUID.randomUUID().toString());
        shippingOrder.setCreationDate(new Date());
        shippingOrder.setStatus("created");
        shippingOrder.setBaseType("ShippingOrder1");
        var entity = mapper.modelToEntity(shippingOrder);
        entity.persist();
        return ControllerHelper.createResponse(uriInfo, shippingOrder);
    }

    public Response getShippingOrders(String fields, Integer offset, Integer limit, UriInfo uriInfo) {
        var sort = uriInfo.getQueryParameters().getFirst("sort");
        var wrapper = new GetRequestWrapper()
                .fields(fields)
                .offset(offset)
                .limit(limit)
                .sort(sort)
                .filters(uriInfo);
        log.info("fetching shipping orders {}", wrapper);

        var orders = ShippingOrderEntity.streamAll()
                .map(e -> (ShippingOrderEntity) e)
                .map(e -> mapper.entityToModel(e, Set.of("*")))
                .toList();
        return Response.ok(orders).build();
    }

    public Response searchShippingOrders(String fields, Integer offset, Integer limit, UriInfo uriInfo) {
        var sort = uriInfo.getQueryParameters().getFirst("sort");
        var wrapper = new GetRequestWrapper()
                .fields(fields)
                .offset(offset)
                .limit(limit)
                .sort(sort)
                .filters(uriInfo);
        log.info("fetching shipping orders {}", wrapper);
        var listWrapper = this.queryBuilder.buildAndRunQuery(wrapper, ShippingOrderEntity.getEntityManager());
        log.info("Returning {} orders out of {} matched ", listWrapper.getData().size(),
                listWrapper.getTotalElements());
        return ControllerHelper.createResponse(wrapper, listWrapper, uriInfo);
    }

    public Response getShippingOrderById(String id) {
        var order = ShippingOrderEntity.findByIdOptional(id).map(e -> (ShippingOrderEntity) e)
                .map(e -> mapper.entityToModel(e, Set.of("*")))
                .orElseThrow(() -> new NotFoundException("ShippingOrder not found", id));
        return Response.ok(order).build();
    }
}
