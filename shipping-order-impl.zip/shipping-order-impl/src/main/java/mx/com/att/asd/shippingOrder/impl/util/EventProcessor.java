package mx.com.att.asd.shippingOrder.impl.util;


import com.comviva.pacs.logging.LoggingConstant;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import mx.com.att.asd.shippingOrder.model.ShippingOrder;
import mx.com.att.asd.shippingOrder.model.ShippingOrderCreateEvent;
import mx.com.att.asd.shippingOrder.model.ShippingOrderCreateEventPayload;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.kafka.KafkaConstants;
import org.slf4j.MDC;

import java.util.Date;
import java.util.UUID;

public class EventProcessor implements Processor {
    private final ObjectMapper objectMapper;

    public EventProcessor(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @Override
    public void process(Exchange exchange) throws JsonProcessingException {
        var order = (ShippingOrder) exchange.getIn().getBody();
        var event = new ShippingOrderCreateEvent();
        event.setEventId(UUID.randomUUID().toString());
        var payload = new ShippingOrderCreateEventPayload();
        payload.setShippingOrder(order);
        event.setEvent(payload);
        event.setEventTime(new Date());
        event.setEventType(exchange.getIn().getHeader("eventType").toString());
        event.setEventId(event.getEventId());
        exchange.getIn().setHeader(KafkaConstants.KEY, order.getId());
        exchange.getIn().setHeader(LoggingConstant.CORRELATION_ID.getHeaderName(),
                MDC.get(LoggingConstant.CORRELATION_ID.getLogkeyName()));
        exchange.getIn().setBody(this.objectMapper.writeValueAsString(event));
    }
}
