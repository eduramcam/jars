package mx.com.att.asd.shippingOrder.impl.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.quarkus.vertx.ConsumeEvent;
import jakarta.annotation.PreDestroy;
import jakarta.enterprise.context.ApplicationScoped;
import lombok.extern.slf4j.Slf4j;
import mx.com.att.asd.shippingOrder.model.ShippingOrder;
import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultCamelContext;
import org.apache.camel.support.SimpleRegistry;
import org.eclipse.microprofile.config.inject.ConfigProperty;

import java.util.Map;

@ApplicationScoped
@Slf4j
public class EventWriter {
    private DefaultCamelContext context;
    private final ProducerTemplate producer;

    public EventWriter(@ConfigProperty(name = "app.event.kafka.bootstrap.servers") String kafkaServers,
                       @ConfigProperty(name = "app.event.kafka.topic") String kafkaTopic, ObjectMapper objectMapper) throws Exception {
        log.info("Initializing kafka camel route...");
        var reg = new SimpleRegistry();
        this.context = new DefaultCamelContext(reg);
        context.addRoutes(new KafkaInsertRouteBuilder(kafkaServers, kafkaTopic, objectMapper));
        log.info("kafka camel route initialized for publishing productOrder events");
        context.start();
        this.producer = context.createProducerTemplate();
    }

    @ConsumeEvent(value = "ShippingOrderCreateEvent", blocking = true)
    public void write(ShippingOrder order) {
        producer.asyncRequestBodyAndHeaders("direct:events", order, Map.of("eventType", "ShippingOrderCreateEvent"));
    }

    @PreDestroy
    public void destroy() {
        log.info("Going to close camel kafka pipeline");
        this.context.stop();
    }
}
