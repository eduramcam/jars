package mx.com.att.asd.shippingOrder.impl.util;

import java.util.Set;
import java.util.stream.Collectors;

public class FieldFilterUtil {
    public static Set<String> getFields(String subEntityName, Set<String> allowedFields) {
        return allowedFields == null ? Set.of("*") : allowedFields
                .stream()
                .filter(e -> e.startsWith(subEntityName) || e.equals("*"))
                .map(e -> e.startsWith(subEntityName + ".") ? e.substring(subEntityName.length() + 1) : e)
                .collect(Collectors.toSet());
    }
}
