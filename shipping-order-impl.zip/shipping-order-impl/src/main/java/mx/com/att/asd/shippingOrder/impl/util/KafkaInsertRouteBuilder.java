package mx.com.att.asd.shippingOrder.impl.util;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.camel.builder.RouteBuilder;

public class KafkaInsertRouteBuilder extends RouteBuilder {
    private final String servers;
    private final String topic;
    private final ObjectMapper objectMapper;

    public KafkaInsertRouteBuilder(String servers, String topic, ObjectMapper objectMapper) {
        this.servers = servers;
        this.topic = topic;
        this.objectMapper = objectMapper;
    }

    @Override
    public void configure() {
        from("direct:events")
                .log("Called publish kafka")
//                .setHeader(LoggingConstant.CORRELATION_ID.getHeaderName(), simple("${body.correlationId}"))
//                .setHeader(LoggingConstant.TRANSACTION_ID.getHeaderName(), simple("${body.transactionId}"))
//                .setHeader(LoggingConstant.USER_ID.getHeaderName(), simple("${body.actor}"))
//                .setHeader(LoggingConstant.TENANT_ID.getHeaderName(), simple("${body.tenantId}"))
//                .setHeader(LoggingConstant.SOURCE_CHANNEL.getHeaderName(), simple("${body.sourceChannel}"))
                .process(new EventProcessor(objectMapper))
                .to("kafka:%s?brokers=%s".formatted(topic, servers));
    }
}
