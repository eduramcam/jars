package mx.com.att.asd.shippingOrder.mappers;

import io.swagger.mappers.ShippingOrderMapperBase;
import org.mapstruct.Mapper;

@Mapper(componentModel = "cdi")
public interface ShippingOrderMapper extends ShippingOrderMapperBase {
}
