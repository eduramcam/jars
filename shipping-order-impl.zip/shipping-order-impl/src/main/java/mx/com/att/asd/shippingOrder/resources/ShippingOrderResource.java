package mx.com.att.asd.shippingOrder.resources;

import io.swagger.model.ShippingOrder;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import mx.com.att.asd.shippingOrder.services.ShippingOrderService;

@Path("/api/v1/shippingOrders")
public class ShippingOrderResource {
    private final ShippingOrderService service;

    public ShippingOrderResource(ShippingOrderService service) {
        this.service = service;
    }

    @POST
    public Response createOrder(ShippingOrder shippingOrder, @QueryParam("fields") String fields, @Context UriInfo uriInfo){
        return this.service.createOrder(shippingOrder,fields,uriInfo);
    }

}
