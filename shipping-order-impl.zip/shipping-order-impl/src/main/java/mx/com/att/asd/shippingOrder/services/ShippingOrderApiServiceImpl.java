package mx.com.att.asd.shippingOrder.services;

import com.comviva.pacs.exceptions.NotFoundException;
import io.swagger.api.ShippingOrderApiService;
import io.swagger.model.ShippingOrderCreate;
import io.swagger.model.ShippingOrderUpdate;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.SecurityContext;

@ApplicationScoped
public class ShippingOrderApiServiceImpl implements ShippingOrderApiService {

    @Override
    public Response createShippingOrder(ShippingOrderCreate shippingOrderCreate, SecurityContext securityContext) throws NotFoundException {
        return null;
    }

    @Override
    public Response listShippingOrder(String s, Integer integer, Integer integer1, SecurityContext securityContext) throws NotFoundException {
        return null;
    }

    @Override
    public Response patchShippingOrder(String s, ShippingOrderUpdate shippingOrderUpdate, SecurityContext securityContext) throws NotFoundException {
        return null;
    }

    @Override
    public Response retrieveShippingOrder(String s, String s1, SecurityContext securityContext) throws NotFoundException {
        return null;
    }

    @Override
    public Response updateShippingOrder(String s, ShippingOrderUpdate shippingOrderUpdate, SecurityContext securityContext) throws NotFoundException {
        return null;
    }
}
