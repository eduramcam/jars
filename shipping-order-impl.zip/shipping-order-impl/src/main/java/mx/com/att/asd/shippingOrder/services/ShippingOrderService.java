package mx.com.att.asd.shippingOrder.services;

import io.swagger.model.ShippingOrder;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import lombok.extern.slf4j.Slf4j;
import mx.com.att.asd.shippingOrder.mappers.ShippingOrderMapper;

import java.util.Date;
import java.util.UUID;

@Slf4j
@ApplicationScoped
public class ShippingOrderService {
    private final ShippingOrderMapper mapper;

    public ShippingOrderService(ShippingOrderMapper mapper) {
        this.mapper = mapper;
    }

    @Transactional
    public Response createOrder(ShippingOrder shippingOrder, String fields, UriInfo uriInfo) {
        log.info("Creating shipping order: {}", shippingOrder);
        shippingOrder.setId(UUID.randomUUID().toString());
        shippingOrder.setCreationDate(new Date());
        var entity=mapper.modelToEntity(shippingOrder);
        entity.persist();
        return Response.ok().entity(shippingOrder).build();
    }
}
