package mx.com.att.asd.shippingOrder.api;


import com.comviva.pacs.exceptions.NotFoundException;
import mx.com.att.asd.shippingOrder.model.ShippingOrderCreate;
import mx.com.att.asd.shippingOrder.model.ShippingOrderUpdate;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;

@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14" +
                                                                                                       ":23:40.334Z")
public interface ShippingOrderApiService {
    Response createShippingOrder(ShippingOrderCreate shippingOrder, SecurityContext securityContext)
            throws NotFoundException;

    Response listShippingOrder(String fields, Integer offset, Integer limit, SecurityContext securityContext)
            throws NotFoundException;

    Response patchShippingOrder(String id, ShippingOrderUpdate shippingOrder, SecurityContext securityContext)
            throws NotFoundException;

    Response retrieveShippingOrder(String id, String fields, SecurityContext securityContext)
            throws NotFoundException;

    Response updateShippingOrder(String id, ShippingOrderUpdate shippingOrder, SecurityContext securityContext)
            throws NotFoundException;
}
