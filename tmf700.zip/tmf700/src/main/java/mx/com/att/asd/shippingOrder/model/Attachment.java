package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

@ApiModel(description="Complements the description of an element (for instance a product) through video, pictures...")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class Attachment   {
  
  private String id = null;
  private String href = null;
  private String attachmentType = null;
  private String content = null;
  private String description = null;
  private String mimeType = null;
  private String name = null;
  private String url = null;
  private Quantity size = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Unique identifier for this particular attachment
   **/
  
  @ApiModelProperty(example = "4aafacbd-11ff-4dc8-b445-305f2215715f", value = "Unique identifier for this particular attachment")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * URI for this Attachment
   **/
  
  @ApiModelProperty(example = "http://host/Attachment/4aafacbd-11ff-4dc8-b445-305f2215715f", value = "URI for this Attachment")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Attachment type such as video, picture
   **/
  
  @ApiModelProperty(example = "video", value = "Attachment type such as video, picture")
  @JsonProperty("attachmentType")
  public String getAttachmentType() {
    return attachmentType;
  }
  public void setAttachmentType(String attachmentType) {
    this.attachmentType = attachmentType;
  }

  /**
   * The actual contents of the attachment object, if embedded, encoded as base64
   **/
  
  @ApiModelProperty(value = "The actual contents of the attachment object, if embedded, encoded as base64")
  @JsonProperty("content")
  public String getContent() {
    return content;
  }
  public void setContent(String content) {
    this.content = content;
  }

  /**
   * A narrative text describing the content of the attachment
   **/
  
  @ApiModelProperty(example = "Photograph of the Product", value = "A narrative text describing the content of the attachment")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Attachment mime type such as extension file for video, picture and document
   **/
  
  @ApiModelProperty(value = "Attachment mime type such as extension file for video, picture and document")
  @JsonProperty("mimeType")
  public String getMimeType() {
    return mimeType;
  }
  public void setMimeType(String mimeType) {
    this.mimeType = mimeType;
  }

  /**
   * The name of the attachment
   **/
  
  @ApiModelProperty(value = "The name of the attachment")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Uniform Resource Locator, is a web page address (a subset of URI)
   **/
  
  @ApiModelProperty(example = "http://host/Content/4aafacbd-11ff-4dc8-b445-305f2215715f", value = "Uniform Resource Locator, is a web page address (a subset of URI)")
  @JsonProperty("url")
  public String getUrl() {
    return url;
  }
  public void setUrl(String url) {
    this.url = url;
  }

  /**
   * The size of the attachment.
   **/
  
  @ApiModelProperty(value = "The size of the attachment.")
  @JsonProperty("size")
  public Quantity getSize() {
    return size;
  }
  public void setSize(Quantity size) {
    this.size = size;
  }

  /**
   * The period of time for which the attachment is valid
   **/
  
  @ApiModelProperty(value = "The period of time for which the attachment is valid")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Attachment attachment = (Attachment) o;
    return Objects.equals(id, attachment.id) &&
        Objects.equals(href, attachment.href) &&
        Objects.equals(attachmentType, attachment.attachmentType) &&
        Objects.equals(content, attachment.content) &&
        Objects.equals(description, attachment.description) &&
        Objects.equals(mimeType, attachment.mimeType) &&
        Objects.equals(name, attachment.name) &&
        Objects.equals(url, attachment.url) &&
        Objects.equals(size, attachment.size) &&
        Objects.equals(validFor, attachment.validFor) &&
        Objects.equals(baseType, attachment.baseType) &&
        Objects.equals(schemaLocation, attachment.schemaLocation) &&
        Objects.equals(type, attachment.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, attachmentType, content, description, mimeType, name, url, size, validFor, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Attachment {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    attachmentType: ").append(toIndentedString(attachmentType)).append("\n");
    sb.append("    content: ").append(toIndentedString(content)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    mimeType: ").append(toIndentedString(mimeType)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    url: ").append(toIndentedString(url)).append("\n");
    sb.append("    size: ").append(toIndentedString(size)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

