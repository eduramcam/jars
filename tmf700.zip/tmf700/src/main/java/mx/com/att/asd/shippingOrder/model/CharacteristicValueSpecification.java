package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

@ApiModel(description="specification of a value (number or text or an object) that can be assigned to a Characteristic.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class CharacteristicValueSpecification   {
  
  private Boolean isDefault = null;
  private String rangeInterval = null;
  private String regex = null;
  private String unitOfMeasure = null;
  private Integer valueFrom = null;
  private Integer valueTo = null;
  private String valueType = null;
  private TimePeriod validFor = null;
  private Any value = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * If true, the Boolean Indicates if the value is the default value for a characteristic
   **/
  
  @ApiModelProperty(value = "If true, the Boolean Indicates if the value is the default value for a characteristic")
  @JsonProperty("isDefault")
  public Boolean isIsDefault() {
    return isDefault;
  }
  public void setIsDefault(Boolean isDefault) {
    this.isDefault = isDefault;
  }

  /**
   * An indicator that specifies the inclusion or exclusion of the valueFrom and valueTo attributes. If applicable, possible values are \&quot;open\&quot;, \&quot;closed\&quot;, \&quot;closedBottom\&quot; and \&quot;closedTop\&quot;.
   **/
  
  @ApiModelProperty(value = "An indicator that specifies the inclusion or exclusion of the valueFrom and valueTo attributes. If applicable, possible values are \"open\", \"closed\", \"closedBottom\" and \"closedTop\".")
  @JsonProperty("rangeInterval")
  public String getRangeInterval() {
    return rangeInterval;
  }
  public void setRangeInterval(String rangeInterval) {
    this.rangeInterval = rangeInterval;
  }

  /**
   * A regular expression constraint for given value
   **/
  
  @ApiModelProperty(value = "A regular expression constraint for given value")
  @JsonProperty("regex")
  public String getRegex() {
    return regex;
  }
  public void setRegex(String regex) {
    this.regex = regex;
  }

  /**
   * A length, surface, volume, dry measure, liquid measure, money, weight, time, and the like. In general, a determinate quantity or magnitude of the kind designated, taken as a standard of comparison for others of the same kind, in assigning to them numerical values, as 1 foot, 1 yard, 1 mile, 1 square foot.
   **/
  
  @ApiModelProperty(value = "A length, surface, volume, dry measure, liquid measure, money, weight, time, and the like. In general, a determinate quantity or magnitude of the kind designated, taken as a standard of comparison for others of the same kind, in assigning to them numerical values, as 1 foot, 1 yard, 1 mile, 1 square foot.")
  @JsonProperty("unitOfMeasure")
  public String getUnitOfMeasure() {
    return unitOfMeasure;
  }
  public void setUnitOfMeasure(String unitOfMeasure) {
    this.unitOfMeasure = unitOfMeasure;
  }

  /**
   * The low range value that a characteristic can take on
   **/
  
  @ApiModelProperty(value = "The low range value that a characteristic can take on")
  @JsonProperty("valueFrom")
  public Integer getValueFrom() {
    return valueFrom;
  }
  public void setValueFrom(Integer valueFrom) {
    this.valueFrom = valueFrom;
  }

  /**
   * The upper range value that a characteristic can take on
   **/
  
  @ApiModelProperty(value = "The upper range value that a characteristic can take on")
  @JsonProperty("valueTo")
  public Integer getValueTo() {
    return valueTo;
  }
  public void setValueTo(Integer valueTo) {
    this.valueTo = valueTo;
  }

  /**
   * A kind of value that the characteristic value can take on, such as numeric, text and so forth
   **/
  
  @ApiModelProperty(value = "A kind of value that the characteristic value can take on, such as numeric, text and so forth")
  @JsonProperty("valueType")
  public String getValueType() {
    return valueType;
  }
  public void setValueType(String valueType) {
    this.valueType = valueType;
  }

  /**
   * The period of time for which a value is applicable.
   **/
  
  @ApiModelProperty(value = "The period of time for which a value is applicable.")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * A discrete value that the characteristic can take on, or the actual value of the characteristic
   **/
  
  @ApiModelProperty(value = "A discrete value that the characteristic can take on, or the actual value of the characteristic")
  @JsonProperty("value")
  public Any getValue() {
    return value;
  }
  public void setValue(Any value) {
    this.value = value;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    CharacteristicValueSpecification characteristicValueSpecification = (CharacteristicValueSpecification) o;
    return Objects.equals(isDefault, characteristicValueSpecification.isDefault) &&
        Objects.equals(rangeInterval, characteristicValueSpecification.rangeInterval) &&
        Objects.equals(regex, characteristicValueSpecification.regex) &&
        Objects.equals(unitOfMeasure, characteristicValueSpecification.unitOfMeasure) &&
        Objects.equals(valueFrom, characteristicValueSpecification.valueFrom) &&
        Objects.equals(valueTo, characteristicValueSpecification.valueTo) &&
        Objects.equals(valueType, characteristicValueSpecification.valueType) &&
        Objects.equals(validFor, characteristicValueSpecification.validFor) &&
        Objects.equals(value, characteristicValueSpecification.value) &&
        Objects.equals(baseType, characteristicValueSpecification.baseType) &&
        Objects.equals(schemaLocation, characteristicValueSpecification.schemaLocation) &&
        Objects.equals(type, characteristicValueSpecification.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(isDefault, rangeInterval, regex, unitOfMeasure, valueFrom, valueTo, valueType, validFor, value, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class CharacteristicValueSpecification {\n");
    
    sb.append("    isDefault: ").append(toIndentedString(isDefault)).append("\n");
    sb.append("    rangeInterval: ").append(toIndentedString(rangeInterval)).append("\n");
    sb.append("    regex: ").append(toIndentedString(regex)).append("\n");
    sb.append("    unitOfMeasure: ").append(toIndentedString(unitOfMeasure)).append("\n");
    sb.append("    valueFrom: ").append(toIndentedString(valueFrom)).append("\n");
    sb.append("    valueTo: ").append(toIndentedString(valueTo)).append("\n");
    sb.append("    valueType: ").append(toIndentedString(valueType)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    value: ").append(toIndentedString(value)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

