package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

@ApiModel(description="Indicates the contact medium that could be used to contact the party.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class ContactMedium   {
  
  private String id = null;
  private String href = null;
  private String mediumType = null;
  private Boolean preferred = null;
  private MediumCharacteristic characteristic = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Type of the contact medium, such as: email address, telephone number, postal address
   **/
  
  @ApiModelProperty(value = "Type of the contact medium, such as: email address, telephone number, postal address")
  @JsonProperty("mediumType")
  public String getMediumType() {
    return mediumType;
  }
  public void setMediumType(String mediumType) {
    this.mediumType = mediumType;
  }

  /**
   * If true, indicates that is the preferred contact medium
   **/
  
  @ApiModelProperty(value = "If true, indicates that is the preferred contact medium")
  @JsonProperty("preferred")
  public Boolean isPreferred() {
    return preferred;
  }
  public void setPreferred(Boolean preferred) {
    this.preferred = preferred;
  }

  /**
   * Any additional characteristic(s) of this contact medium
   **/
  
  @ApiModelProperty(value = "Any additional characteristic(s) of this contact medium")
  @JsonProperty("characteristic")
  public MediumCharacteristic getCharacteristic() {
    return characteristic;
  }
  public void setCharacteristic(MediumCharacteristic characteristic) {
    this.characteristic = characteristic;
  }

  /**
   * The time period that the contact medium is valid for
   **/
  
  @ApiModelProperty(value = "The time period that the contact medium is valid for")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ContactMedium contactMedium = (ContactMedium) o;
    return Objects.equals(id, contactMedium.id) &&
        Objects.equals(href, contactMedium.href) &&
        Objects.equals(mediumType, contactMedium.mediumType) &&
        Objects.equals(preferred, contactMedium.preferred) &&
        Objects.equals(characteristic, contactMedium.characteristic) &&
        Objects.equals(validFor, contactMedium.validFor) &&
        Objects.equals(baseType, contactMedium.baseType) &&
        Objects.equals(schemaLocation, contactMedium.schemaLocation) &&
        Objects.equals(type, contactMedium.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, mediumType, preferred, characteristic, validFor, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ContactMedium {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    mediumType: ").append(toIndentedString(mediumType)).append("\n");
    sb.append("    preferred: ").append(toIndentedString(preferred)).append("\n");
    sb.append("    characteristic: ").append(toIndentedString(characteristic)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

