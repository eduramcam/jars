package mx.com.att.asd.shippingOrder.model;

import mx.com.att.asd.shippingOrder.util.ModelExtender;

@ModelExtender(value = ShippingOrder.class)
public interface Extender {
}
