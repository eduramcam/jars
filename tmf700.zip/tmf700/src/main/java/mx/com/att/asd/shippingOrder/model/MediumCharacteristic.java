package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

@ApiModel(description="Describes the contact medium characteristics that could be used to contact a party (an individual or an organization)")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class MediumCharacteristic   {
  
  private String id = null;
  private String href = null;
  private String city = null;
  private String contactType = null;
  private String country = null;
  private String emailAddress = null;
  private String faxNumber = null;
  private String phoneNumber = null;
  private String postCode = null;
  private String socialNetworkId = null;
  private String stateOrProvince = null;
  private String street1 = null;
  private String street2 = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * The city
   **/
  
  @ApiModelProperty(value = "The city")
  @JsonProperty("city")
  public String getCity() {
    return city;
  }
  public void setCity(String city) {
    this.city = city;
  }

  /**
   * The type of contact, for example: phone number such as mobile, fixed home, fixed office. postal address such as shipping instalation…
   **/
  
  @ApiModelProperty(value = "The type of contact, for example: phone number such as mobile, fixed home, fixed office. postal address such as shipping instalation…")
  @JsonProperty("contactType")
  public String getContactType() {
    return contactType;
  }
  public void setContactType(String contactType) {
    this.contactType = contactType;
  }

  /**
   * The country
   **/
  
  @ApiModelProperty(value = "The country")
  @JsonProperty("country")
  public String getCountry() {
    return country;
  }
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * Full email address in standard format
   **/
  
  @ApiModelProperty(value = "Full email address in standard format")
  @JsonProperty("emailAddress")
  public String getEmailAddress() {
    return emailAddress;
  }
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }

  /**
   * The fax number of the contact
   **/
  
  @ApiModelProperty(value = "The fax number of the contact")
  @JsonProperty("faxNumber")
  public String getFaxNumber() {
    return faxNumber;
  }
  public void setFaxNumber(String faxNumber) {
    this.faxNumber = faxNumber;
  }

  /**
   * The primary phone number of the contact
   **/
  
  @ApiModelProperty(value = "The primary phone number of the contact")
  @JsonProperty("phoneNumber")
  public String getPhoneNumber() {
    return phoneNumber;
  }
  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }

  /**
   * Postcode
   **/
  
  @ApiModelProperty(value = "Postcode")
  @JsonProperty("postCode")
  public String getPostCode() {
    return postCode;
  }
  public void setPostCode(String postCode) {
    this.postCode = postCode;
  }

  /**
   * Identifier as a member of a social network
   **/
  
  @ApiModelProperty(value = "Identifier as a member of a social network")
  @JsonProperty("socialNetworkId")
  public String getSocialNetworkId() {
    return socialNetworkId;
  }
  public void setSocialNetworkId(String socialNetworkId) {
    this.socialNetworkId = socialNetworkId;
  }

  /**
   * State or province
   **/
  
  @ApiModelProperty(value = "State or province")
  @JsonProperty("stateOrProvince")
  public String getStateOrProvince() {
    return stateOrProvince;
  }
  public void setStateOrProvince(String stateOrProvince) {
    this.stateOrProvince = stateOrProvince;
  }

  /**
   * Describes the street
   **/
  
  @ApiModelProperty(value = "Describes the street")
  @JsonProperty("street1")
  public String getStreet1() {
    return street1;
  }
  public void setStreet1(String street1) {
    this.street1 = street1;
  }

  /**
   * Complementary street description
   **/
  
  @ApiModelProperty(value = "Complementary street description")
  @JsonProperty("street2")
  public String getStreet2() {
    return street2;
  }
  public void setStreet2(String street2) {
    this.street2 = street2;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    MediumCharacteristic mediumCharacteristic = (MediumCharacteristic) o;
    return Objects.equals(id, mediumCharacteristic.id) &&
        Objects.equals(href, mediumCharacteristic.href) &&
        Objects.equals(city, mediumCharacteristic.city) &&
        Objects.equals(contactType, mediumCharacteristic.contactType) &&
        Objects.equals(country, mediumCharacteristic.country) &&
        Objects.equals(emailAddress, mediumCharacteristic.emailAddress) &&
        Objects.equals(faxNumber, mediumCharacteristic.faxNumber) &&
        Objects.equals(phoneNumber, mediumCharacteristic.phoneNumber) &&
        Objects.equals(postCode, mediumCharacteristic.postCode) &&
        Objects.equals(socialNetworkId, mediumCharacteristic.socialNetworkId) &&
        Objects.equals(stateOrProvince, mediumCharacteristic.stateOrProvince) &&
        Objects.equals(street1, mediumCharacteristic.street1) &&
        Objects.equals(street2, mediumCharacteristic.street2) &&
        Objects.equals(baseType, mediumCharacteristic.baseType) &&
        Objects.equals(schemaLocation, mediumCharacteristic.schemaLocation) &&
        Objects.equals(type, mediumCharacteristic.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, city, contactType, country, emailAddress, faxNumber, phoneNumber, postCode, socialNetworkId, stateOrProvince, street1, street2, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class MediumCharacteristic {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    city: ").append(toIndentedString(city)).append("\n");
    sb.append("    contactType: ").append(toIndentedString(contactType)).append("\n");
    sb.append("    country: ").append(toIndentedString(country)).append("\n");
    sb.append("    emailAddress: ").append(toIndentedString(emailAddress)).append("\n");
    sb.append("    faxNumber: ").append(toIndentedString(faxNumber)).append("\n");
    sb.append("    phoneNumber: ").append(toIndentedString(phoneNumber)).append("\n");
    sb.append("    postCode: ").append(toIndentedString(postCode)).append("\n");
    sb.append("    socialNetworkId: ").append(toIndentedString(socialNetworkId)).append("\n");
    sb.append("    stateOrProvince: ").append(toIndentedString(stateOrProvince)).append("\n");
    sb.append("    street1: ").append(toIndentedString(street1)).append("\n");
    sb.append("    street2: ").append(toIndentedString(street2)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

