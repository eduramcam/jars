package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@ApiModel(description="A product offering procured by a customer or other interested party playing a party role. A product is realized as one or more service(s) and / or resource(s).")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class Product   {
  
  private String id = null;
  private String href = null;
  private String description = null;
  private Boolean isBundle = null;
  private Boolean isCustomerVisible = null;
  private String name = null;
  private Date orderDate = null;
  private String productSerialNumber = null;
  private Date startDate = null;
  private Date terminationDate = null;
  private List<AgreementItemRef> agreement = new ArrayList<AgreementItemRef>();
  private BillingAccountRef billingAccount = null;
  private List<RelatedPlaceRefOrValue> place = new ArrayList<RelatedPlaceRefOrValue>();
  private List<ProductRefOrValue> product = new ArrayList<ProductRefOrValue>();
  private List<Characteristic> productCharacteristic = new ArrayList<Characteristic>();
  private ProductOfferingRef productOffering = null;
  private List<RelatedProductOrderItem> productOrderItem = new ArrayList<RelatedProductOrderItem>();
  private List<ProductPrice> productPrice = new ArrayList<ProductPrice>();
  private List<ProductRelationship> productRelationship = new ArrayList<ProductRelationship>();
  private ProductSpecificationRef productSpecification = null;
  private List<ProductTerm> productTerm = new ArrayList<ProductTerm>();
  private List<ResourceRef> realizingResource = new ArrayList<ResourceRef>();
  private List<ServiceRef> realizingService = new ArrayList<ServiceRef>();
  private List<RelatedParty> relatedParty = new ArrayList<RelatedParty>();
  private ProductStatusType status = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * Unique identifier of the product
   **/
  
  @ApiModelProperty(value = "Unique identifier of the product")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Reference of the product
   **/
  
  @ApiModelProperty(value = "Reference of the product")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Is the description of the product. It could be copied from the description of the Product Offering.
   **/
  
  @ApiModelProperty(value = "Is the description of the product. It could be copied from the description of the Product Offering.")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * If true, the product is a ProductBundle which is an instantiation of a BundledProductOffering. If false, the product is a ProductComponent which is an instantiation of a SimpleProductOffering.
   **/
  
  @ApiModelProperty(value = "If true, the product is a ProductBundle which is an instantiation of a BundledProductOffering. If false, the product is a ProductComponent which is an instantiation of a SimpleProductOffering.")
  @JsonProperty("isBundle")
  public Boolean isIsBundle() {
    return isBundle;
  }
  public void setIsBundle(Boolean isBundle) {
    this.isBundle = isBundle;
  }

  /**
   * If true, the product is visible by the customer.
   **/
  
  @ApiModelProperty(value = "If true, the product is visible by the customer.")
  @JsonProperty("isCustomerVisible")
  public Boolean isIsCustomerVisible() {
    return isCustomerVisible;
  }
  public void setIsCustomerVisible(Boolean isCustomerVisible) {
    this.isCustomerVisible = isCustomerVisible;
  }

  /**
   * Name of the product. It could be the same as the name of the product offering
   **/
  
  @ApiModelProperty(value = "Name of the product. It could be the same as the name of the product offering")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Is the date when the product was ordered
   **/
  
  @ApiModelProperty(value = "Is the date when the product was ordered")
  @JsonProperty("orderDate")
  public Date getOrderDate() {
    return orderDate;
  }
  public void setOrderDate(Date orderDate) {
    this.orderDate = orderDate;
  }

  /**
   * Is the serial number for the product. This is typically applicable to tangible products e.g. Broadband Router.
   **/
  
  @ApiModelProperty(value = "Is the serial number for the product. This is typically applicable to tangible products e.g. Broadband Router.")
  @JsonProperty("productSerialNumber")
  public String getProductSerialNumber() {
    return productSerialNumber;
  }
  public void setProductSerialNumber(String productSerialNumber) {
    this.productSerialNumber = productSerialNumber;
  }

  /**
   * Is the date from which the product starts
   **/
  
  @ApiModelProperty(value = "Is the date from which the product starts")
  @JsonProperty("startDate")
  public Date getStartDate() {
    return startDate;
  }
  public void setStartDate(Date startDate) {
    this.startDate = startDate;
  }

  /**
   * Is the date when the product was terminated
   **/
  
  @ApiModelProperty(value = "Is the date when the product was terminated")
  @JsonProperty("terminationDate")
  public Date getTerminationDate() {
    return terminationDate;
  }
  public void setTerminationDate(Date terminationDate) {
    this.terminationDate = terminationDate;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("agreement")
  public List<AgreementItemRef> getAgreement() {
    return agreement;
  }
  public void setAgreement(List<AgreementItemRef> agreement) {
    this.agreement = agreement;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("billingAccount")
  public BillingAccountRef getBillingAccount() {
    return billingAccount;
  }
  public void setBillingAccount(BillingAccountRef billingAccount) {
    this.billingAccount = billingAccount;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("place")
  public List<RelatedPlaceRefOrValue> getPlace() {
    return place;
  }
  public void setPlace(List<RelatedPlaceRefOrValue> place) {
    this.place = place;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("product")
  public List<ProductRefOrValue> getProduct() {
    return product;
  }
  public void setProduct(List<ProductRefOrValue> product) {
    this.product = product;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productCharacteristic")
  public List<Characteristic> getProductCharacteristic() {
    return productCharacteristic;
  }
  public void setProductCharacteristic(List<Characteristic> productCharacteristic) {
    this.productCharacteristic = productCharacteristic;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productOffering")
  public ProductOfferingRef getProductOffering() {
    return productOffering;
  }
  public void setProductOffering(ProductOfferingRef productOffering) {
    this.productOffering = productOffering;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productOrderItem")
  public List<RelatedProductOrderItem> getProductOrderItem() {
    return productOrderItem;
  }
  public void setProductOrderItem(List<RelatedProductOrderItem> productOrderItem) {
    this.productOrderItem = productOrderItem;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productPrice")
  public List<ProductPrice> getProductPrice() {
    return productPrice;
  }
  public void setProductPrice(List<ProductPrice> productPrice) {
    this.productPrice = productPrice;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productRelationship")
  public List<ProductRelationship> getProductRelationship() {
    return productRelationship;
  }
  public void setProductRelationship(List<ProductRelationship> productRelationship) {
    this.productRelationship = productRelationship;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productSpecification")
  public ProductSpecificationRef getProductSpecification() {
    return productSpecification;
  }
  public void setProductSpecification(ProductSpecificationRef productSpecification) {
    this.productSpecification = productSpecification;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("productTerm")
  public List<ProductTerm> getProductTerm() {
    return productTerm;
  }
  public void setProductTerm(List<ProductTerm> productTerm) {
    this.productTerm = productTerm;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("realizingResource")
  public List<ResourceRef> getRealizingResource() {
    return realizingResource;
  }
  public void setRealizingResource(List<ResourceRef> realizingResource) {
    this.realizingResource = realizingResource;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("realizingService")
  public List<ServiceRef> getRealizingService() {
    return realizingService;
  }
  public void setRealizingService(List<ServiceRef> realizingService) {
    this.realizingService = realizingService;
  }

  /**
   **/
  
  @ApiModelProperty(value = "")
  @JsonProperty("relatedParty")
  public List<RelatedParty> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedParty> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * Is the lifecycle status of the product.
   **/
  
  @ApiModelProperty(value = "Is the lifecycle status of the product.")
  @JsonProperty("status")
  public ProductStatusType getStatus() {
    return status;
  }
  public void setStatus(ProductStatusType status) {
    this.status = status;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Product product = (Product) o;
    return Objects.equals(id, product.id) &&
        Objects.equals(href, product.href) &&
        Objects.equals(description, product.description) &&
        Objects.equals(isBundle, product.isBundle) &&
        Objects.equals(isCustomerVisible, product.isCustomerVisible) &&
        Objects.equals(name, product.name) &&
        Objects.equals(orderDate, product.orderDate) &&
        Objects.equals(productSerialNumber, product.productSerialNumber) &&
        Objects.equals(startDate, product.startDate) &&
        Objects.equals(terminationDate, product.terminationDate) &&
        Objects.equals(agreement, product.agreement) &&
        Objects.equals(billingAccount, product.billingAccount) &&
        Objects.equals(place, product.place) &&
        Objects.equals(product, product.product) &&
        Objects.equals(productCharacteristic, product.productCharacteristic) &&
        Objects.equals(productOffering, product.productOffering) &&
        Objects.equals(productOrderItem, product.productOrderItem) &&
        Objects.equals(productPrice, product.productPrice) &&
        Objects.equals(productRelationship, product.productRelationship) &&
        Objects.equals(productSpecification, product.productSpecification) &&
        Objects.equals(productTerm, product.productTerm) &&
        Objects.equals(realizingResource, product.realizingResource) &&
        Objects.equals(realizingService, product.realizingService) &&
        Objects.equals(relatedParty, product.relatedParty) &&
        Objects.equals(status, product.status) &&
        Objects.equals(baseType, product.baseType) &&
        Objects.equals(schemaLocation, product.schemaLocation) &&
        Objects.equals(type, product.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, description, isBundle, isCustomerVisible, name, orderDate, productSerialNumber, startDate, terminationDate, agreement, billingAccount, place, product, productCharacteristic, productOffering, productOrderItem, productPrice, productRelationship, productSpecification, productTerm, realizingResource, realizingService, relatedParty, status, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Product {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    isBundle: ").append(toIndentedString(isBundle)).append("\n");
    sb.append("    isCustomerVisible: ").append(toIndentedString(isCustomerVisible)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    orderDate: ").append(toIndentedString(orderDate)).append("\n");
    sb.append("    productSerialNumber: ").append(toIndentedString(productSerialNumber)).append("\n");
    sb.append("    startDate: ").append(toIndentedString(startDate)).append("\n");
    sb.append("    terminationDate: ").append(toIndentedString(terminationDate)).append("\n");
    sb.append("    agreement: ").append(toIndentedString(agreement)).append("\n");
    sb.append("    billingAccount: ").append(toIndentedString(billingAccount)).append("\n");
    sb.append("    place: ").append(toIndentedString(place)).append("\n");
    sb.append("    product: ").append(toIndentedString(product)).append("\n");
    sb.append("    productCharacteristic: ").append(toIndentedString(productCharacteristic)).append("\n");
    sb.append("    productOffering: ").append(toIndentedString(productOffering)).append("\n");
    sb.append("    productOrderItem: ").append(toIndentedString(productOrderItem)).append("\n");
    sb.append("    productPrice: ").append(toIndentedString(productPrice)).append("\n");
    sb.append("    productRelationship: ").append(toIndentedString(productRelationship)).append("\n");
    sb.append("    productSpecification: ").append(toIndentedString(productSpecification)).append("\n");
    sb.append("    productTerm: ").append(toIndentedString(productTerm)).append("\n");
    sb.append("    realizingResource: ").append(toIndentedString(realizingResource)).append("\n");
    sb.append("    realizingService: ").append(toIndentedString(realizingService)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

