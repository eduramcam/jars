package mx.com.att.asd.shippingOrder.model;

public enum ProductStatusType {
    created, pendingActive, cancelled, active, pendingTerminate, terminated, suspended, aborted
}
