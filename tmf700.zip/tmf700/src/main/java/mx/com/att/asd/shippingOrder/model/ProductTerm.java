package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

@ApiModel(description="Description of a productTerm linked to this product. This represent a commitment with a duration")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class ProductTerm   {
  
  private String id = null;
  private String href = null;
  private String description = null;
  private String name = null;
  private Quantity duration = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Description of the productTerm
   **/
  
  @ApiModelProperty(value = "Description of the productTerm")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * Name of the productTerm
   **/
  
  @ApiModelProperty(value = "Name of the productTerm")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Duration of the productTerm
   **/
  
  @ApiModelProperty(value = "Duration of the productTerm")
  @JsonProperty("duration")
  public Quantity getDuration() {
    return duration;
  }
  public void setDuration(Quantity duration) {
    this.duration = duration;
  }

  /**
   * productTerm validity period
   **/
  
  @ApiModelProperty(value = "productTerm validity period")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ProductTerm productTerm = (ProductTerm) o;
    return Objects.equals(id, productTerm.id) &&
        Objects.equals(href, productTerm.href) &&
        Objects.equals(description, productTerm.description) &&
        Objects.equals(name, productTerm.name) &&
        Objects.equals(duration, productTerm.duration) &&
        Objects.equals(validFor, productTerm.validFor) &&
        Objects.equals(baseType, productTerm.baseType) &&
        Objects.equals(schemaLocation, productTerm.schemaLocation) &&
        Objects.equals(type, productTerm.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, description, name, duration, validFor, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ProductTerm {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    duration: ").append(toIndentedString(duration)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

