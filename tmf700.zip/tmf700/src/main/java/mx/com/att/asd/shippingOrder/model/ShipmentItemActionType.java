package mx.com.att.asd.shippingOrder.model;

public enum ShipmentItemActionType {
    add, modify, delete, noChange
}
