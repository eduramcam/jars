package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@ApiModel(description="A shipment defined by value or existing defined by reference. The polymorphic attributes @type, @schemaLocation &amp; @referredType are related to the shipment entity and not the related ShipmentRefOrValue class itself")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class ShipmentRefOrValue   {
  
  private String id = null;
  private String href = null;
  private Date collectionDate = null;
  private Date completionDate = null;
  private Date deliveryDate = null;
  private String description = null;
  private Date expectedDeliveryDate = null;
  private String name = null;
  private Date requestedDeliveryDate = null;
  private String state = null;
  private List<AttachmentRefOrValue> attachment = new ArrayList<AttachmentRefOrValue>();
  private List<ExternalIdentifier> externalIdentifier = new ArrayList<ExternalIdentifier>();
  private List<Note> note = new ArrayList<Note>();
  private PaymentMethodRef paymentMethod = null;
  private RelatedPlaceRefOrValue placeFrom = null;
  private RelatedPlaceRefOrValue placeTo = null;
  private List<RelatedPartyWithContactInfo> relatedParty = new ArrayList<RelatedPartyWithContactInfo>();
  private List<RelatedShipment> relatedShipment = new ArrayList<RelatedShipment>();
  private List<Characteristic> shipmentCharacteristic = new ArrayList<Characteristic>();
  private List<ShipmentItem> shipmentItem = new ArrayList<ShipmentItem>();
  private ProductPrice shipmentPrice = null;
  private ShipmentSpecificationRefOrValue shipmentSpecification = null;
  private ShipmentTrackingRef shipmentTracking = null;
  private ShippingInstruction shippingInstruction = null;
  private Quantity weight = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;
  private String referredType = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * The date the package was collected from the carrier (Collection scenario)
   **/
  
  @ApiModelProperty(example = "2020-11-18T08:00:00Z", value = "The date the package was collected from the carrier (Collection scenario)")
  @JsonProperty("collectionDate")
  public Date getCollectionDate() {
    return collectionDate;
  }
  public void setCollectionDate(Date collectionDate) {
    this.collectionDate = collectionDate;
  }

  /**
   * Effective delivery date amended by the provider
   **/
  
  @ApiModelProperty(example = "2020-11-20T08:00:00Z", value = "Effective delivery date amended by the provider")
  @JsonProperty("completionDate")
  public Date getCompletionDate() {
    return completionDate;
  }
  public void setCompletionDate(Date completionDate) {
    this.completionDate = completionDate;
  }

  /**
   * Is the date at which the shipment was completed (customer has taken ownership of the package)
   **/
  
  @ApiModelProperty(example = "2020-11-20T08:00:00Z", value = "Is the date at which the shipment was completed (customer has taken ownership of the package)")
  @JsonProperty("deliveryDate")
  public Date getDeliveryDate() {
    return deliveryDate;
  }
  public void setDeliveryDate(Date deliveryDate) {
    this.deliveryDate = deliveryDate;
  }

  /**
   * Description of the shipment. It could be the same as the description of the shipment specification.
   **/
  
  @ApiModelProperty(example = "Cartridges for Ink Ltd", value = "Description of the shipment. It could be the same as the description of the shipment specification.")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * The date that the shipment will be delivered
   **/
  
  @ApiModelProperty(example = "2020-11-20T08:00:00Z", value = "The date that the shipment will be delivered")
  @JsonProperty("expectedDeliveryDate")
  public Date getExpectedDeliveryDate() {
    return expectedDeliveryDate;
  }
  public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
    this.expectedDeliveryDate = expectedDeliveryDate;
  }

  /**
   * Name of the related entity.
   **/
  
  @ApiModelProperty(value = "Name of the related entity.")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * The date requester by the sender for shipment delivery
   **/
  
  @ApiModelProperty(example = "2020-11-20T08:00:00Z", value = "The date requester by the sender for shipment delivery")
  @JsonProperty("requestedDeliveryDate")
  public Date getRequestedDeliveryDate() {
    return requestedDeliveryDate;
  }
  public void setRequestedDeliveryDate(Date requestedDeliveryDate) {
    this.requestedDeliveryDate = requestedDeliveryDate;
  }

  /**
   * The current status of the shipment.
   **/
  
  @ApiModelProperty(example = "labelPrinted", value = "The current status of the shipment.")
  @JsonProperty("state")
  public String getState() {
    return state;
  }
  public void setState(String state) {
    this.state = state;
  }

  /**
   * Attachments that may be of relevance to this shipment, such as shippingLabels, Signature or photos of the delivery  
   **/
  
  @ApiModelProperty(value = "Attachments that may be of relevance to this shipment, such as shippingLabels, Signature or photos of the delivery  ")
  @JsonProperty("attachment")
  public List<AttachmentRefOrValue> getAttachment() {
    return attachment;
  }
  public void setAttachment(List<AttachmentRefOrValue> attachment) {
    this.attachment = attachment;
  }

  /**
   * An identification of an entity that is owned by or originates in a software system different from the current system, for example a ProductOrder handed off from a commerce platform into an order handling system. The structure identifies the system itself, the nature of the entity within the system (e.g. class name) and the unique ID of the entity within the system. It is anticipated that multiple external IDs can be held for a single entity, e.g. if the entity passed through multiple systems on the way to the current system. In this case the consumer is expected to sequence the IDs in the array in reverse order of provenance, i.e. most recent system first in the list.
   **/
  
  @ApiModelProperty(value = "An identification of an entity that is owned by or originates in a software system different from the current system, for example a ProductOrder handed off from a commerce platform into an order handling system. The structure identifies the system itself, the nature of the entity within the system (e.g. class name) and the unique ID of the entity within the system. It is anticipated that multiple external IDs can be held for a single entity, e.g. if the entity passed through multiple systems on the way to the current system. In this case the consumer is expected to sequence the IDs in the array in reverse order of provenance, i.e. most recent system first in the list.")
  @JsonProperty("externalIdentifier")
  public List<ExternalIdentifier> getExternalIdentifier() {
    return externalIdentifier;
  }
  public void setExternalIdentifier(List<ExternalIdentifier> externalIdentifier) {
    this.externalIdentifier = externalIdentifier;
  }

  /**
   * A list of notes made on this shipment
   **/
  
  @ApiModelProperty(value = "A list of notes made on this shipment")
  @JsonProperty("note")
  public List<Note> getNote() {
    return note;
  }
  public void setNote(List<Note> note) {
    this.note = note;
  }

  /**
   * Payment method to be used when delivering the package(e.g.: cash, credit card, ). Structure including at least attribute name. Notice that the use of a voucher can be managed as a specific methodtype, where he voucher code can be passed as value.
   **/
  
  @ApiModelProperty(value = "Payment method to be used when delivering the package(e.g.: cash, credit card, ). Structure including at least attribute name. Notice that the use of a voucher can be managed as a specific methodtype, where he voucher code can be passed as value.")
  @JsonProperty("paymentMethod")
  public PaymentMethodRef getPaymentMethod() {
    return paymentMethod;
  }
  public void setPaymentMethod(PaymentMethodRef paymentMethod) {
    this.paymentMethod = paymentMethod;
  }

  /**
   * Source location of the package. E.g. warehouse or shop location
   **/
  
  @ApiModelProperty(value = "Source location of the package. E.g. warehouse or shop location")
  @JsonProperty("placeFrom")
  public RelatedPlaceRefOrValue getPlaceFrom() {
    return placeFrom;
  }
  public void setPlaceFrom(RelatedPlaceRefOrValue placeFrom) {
    this.placeFrom = placeFrom;
  }

  /**
   * Destination of the package. E.g. customer home address
   **/
  
  @ApiModelProperty(value = "Destination of the package. E.g. customer home address")
  @JsonProperty("placeTo")
  public RelatedPlaceRefOrValue getPlaceTo() {
    return placeTo;
  }
  public void setPlaceTo(RelatedPlaceRefOrValue placeTo) {
    this.placeTo = placeTo;
  }

  /**
   * A list of parties which are involved in this shipment and the role they are playing
   **/
  
  @ApiModelProperty(value = "A list of parties which are involved in this shipment and the role they are playing")
  @JsonProperty("relatedParty")
  public List<RelatedPartyWithContactInfo> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedPartyWithContactInfo> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * A list of existing shipments that has some form of correlation with the given shipment
   **/
  
  @ApiModelProperty(value = "A list of existing shipments that has some form of correlation with the given shipment")
  @JsonProperty("relatedShipment")
  public List<RelatedShipment> getRelatedShipment() {
    return relatedShipment;
  }
  public void setRelatedShipment(List<RelatedShipment> relatedShipment) {
    this.relatedShipment = relatedShipment;
  }

  /**
   * List of characteristics with values
   **/
  
  @ApiModelProperty(value = "List of characteristics with values")
  @JsonProperty("shipmentCharacteristic")
  public List<Characteristic> getShipmentCharacteristic() {
    return shipmentCharacteristic;
  }
  public void setShipmentCharacteristic(List<Characteristic> shipmentCharacteristic) {
    this.shipmentCharacteristic = shipmentCharacteristic;
  }

  /**
   * List of items that are part of the shipment (parcel/package)
   **/
  
  @ApiModelProperty(value = "List of items that are part of the shipment (parcel/package)")
  @JsonProperty("shipmentItem")
  public List<ShipmentItem> getShipmentItem() {
    return shipmentItem;
  }
  public void setShipmentItem(List<ShipmentItem> shipmentItem) {
    this.shipmentItem = shipmentItem;
  }

  /**
   * Shipment price
   **/
  
  @ApiModelProperty(value = "Shipment price")
  @JsonProperty("shipmentPrice")
  public ProductPrice getShipmentPrice() {
    return shipmentPrice;
  }
  public void setShipmentPrice(ProductPrice shipmentPrice) {
    this.shipmentPrice = shipmentPrice;
  }

  /**
   * A set of characteristics to describe the shipment
   **/
  
  @ApiModelProperty(value = "A set of characteristics to describe the shipment")
  @JsonProperty("shipmentSpecification")
  public ShipmentSpecificationRefOrValue getShipmentSpecification() {
    return shipmentSpecification;
  }
  public void setShipmentSpecification(ShipmentSpecificationRefOrValue shipmentSpecification) {
    this.shipmentSpecification = shipmentSpecification;
  }

  /**
   * A reference number usually provided by the delivery partner(carrier) used to identify and track shipments across the delivery network
   **/
  
  @ApiModelProperty(value = "A reference number usually provided by the delivery partner(carrier) used to identify and track shipments across the delivery network")
  @JsonProperty("shipmentTracking")
  public ShipmentTrackingRef getShipmentTracking() {
    return shipmentTracking;
  }
  public void setShipmentTracking(ShipmentTrackingRef shipmentTracking) {
    this.shipmentTracking = shipmentTracking;
  }

  /**
   * Shipping instructions, usually relevant for the carrier.
   **/
  
  @ApiModelProperty(value = "Shipping instructions, usually relevant for the carrier.")
  @JsonProperty("shippingInstruction")
  public ShippingInstruction getShippingInstruction() {
    return shippingInstruction;
  }
  public void setShippingInstruction(ShippingInstruction shippingInstruction) {
    this.shippingInstruction = shippingInstruction;
  }

  /**
   * Weight of the shipping package/parcel
   **/
  
  @ApiModelProperty(value = "Weight of the shipping package/parcel")
  @JsonProperty("weight")
  public Quantity getWeight() {
    return weight;
  }
  public void setWeight(Quantity weight) {
    this.weight = weight;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }

  /**
   * The actual type of the target instance when needed for disambiguation.
   **/
  
  @ApiModelProperty(value = "The actual type of the target instance when needed for disambiguation.")
  @JsonProperty("@referredType")
  public String getReferredType() {
    return referredType;
  }
  public void setReferredType(String referredType) {
    this.referredType = referredType;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShipmentRefOrValue shipmentRefOrValue = (ShipmentRefOrValue) o;
    return Objects.equals(id, shipmentRefOrValue.id) &&
        Objects.equals(href, shipmentRefOrValue.href) &&
        Objects.equals(collectionDate, shipmentRefOrValue.collectionDate) &&
        Objects.equals(completionDate, shipmentRefOrValue.completionDate) &&
        Objects.equals(deliveryDate, shipmentRefOrValue.deliveryDate) &&
        Objects.equals(description, shipmentRefOrValue.description) &&
        Objects.equals(expectedDeliveryDate, shipmentRefOrValue.expectedDeliveryDate) &&
        Objects.equals(name, shipmentRefOrValue.name) &&
        Objects.equals(requestedDeliveryDate, shipmentRefOrValue.requestedDeliveryDate) &&
        Objects.equals(state, shipmentRefOrValue.state) &&
        Objects.equals(attachment, shipmentRefOrValue.attachment) &&
        Objects.equals(externalIdentifier, shipmentRefOrValue.externalIdentifier) &&
        Objects.equals(note, shipmentRefOrValue.note) &&
        Objects.equals(paymentMethod, shipmentRefOrValue.paymentMethod) &&
        Objects.equals(placeFrom, shipmentRefOrValue.placeFrom) &&
        Objects.equals(placeTo, shipmentRefOrValue.placeTo) &&
        Objects.equals(relatedParty, shipmentRefOrValue.relatedParty) &&
        Objects.equals(relatedShipment, shipmentRefOrValue.relatedShipment) &&
        Objects.equals(shipmentCharacteristic, shipmentRefOrValue.shipmentCharacteristic) &&
        Objects.equals(shipmentItem, shipmentRefOrValue.shipmentItem) &&
        Objects.equals(shipmentPrice, shipmentRefOrValue.shipmentPrice) &&
        Objects.equals(shipmentSpecification, shipmentRefOrValue.shipmentSpecification) &&
        Objects.equals(shipmentTracking, shipmentRefOrValue.shipmentTracking) &&
        Objects.equals(shippingInstruction, shipmentRefOrValue.shippingInstruction) &&
        Objects.equals(weight, shipmentRefOrValue.weight) &&
        Objects.equals(baseType, shipmentRefOrValue.baseType) &&
        Objects.equals(schemaLocation, shipmentRefOrValue.schemaLocation) &&
        Objects.equals(type, shipmentRefOrValue.type) &&
        Objects.equals(referredType, shipmentRefOrValue.referredType);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, collectionDate, completionDate, deliveryDate, description, expectedDeliveryDate, name, requestedDeliveryDate, state, attachment, externalIdentifier, note, paymentMethod, placeFrom, placeTo, relatedParty, relatedShipment, shipmentCharacteristic, shipmentItem, shipmentPrice, shipmentSpecification, shipmentTracking, shippingInstruction, weight, baseType, schemaLocation, type, referredType);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentRefOrValue {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    collectionDate: ").append(toIndentedString(collectionDate)).append("\n");
    sb.append("    completionDate: ").append(toIndentedString(completionDate)).append("\n");
    sb.append("    deliveryDate: ").append(toIndentedString(deliveryDate)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    expectedDeliveryDate: ").append(toIndentedString(expectedDeliveryDate)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    requestedDeliveryDate: ").append(toIndentedString(requestedDeliveryDate)).append("\n");
    sb.append("    state: ").append(toIndentedString(state)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    externalIdentifier: ").append(toIndentedString(externalIdentifier)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    paymentMethod: ").append(toIndentedString(paymentMethod)).append("\n");
    sb.append("    placeFrom: ").append(toIndentedString(placeFrom)).append("\n");
    sb.append("    placeTo: ").append(toIndentedString(placeTo)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    relatedShipment: ").append(toIndentedString(relatedShipment)).append("\n");
    sb.append("    shipmentCharacteristic: ").append(toIndentedString(shipmentCharacteristic)).append("\n");
    sb.append("    shipmentItem: ").append(toIndentedString(shipmentItem)).append("\n");
    sb.append("    shipmentPrice: ").append(toIndentedString(shipmentPrice)).append("\n");
    sb.append("    shipmentSpecification: ").append(toIndentedString(shipmentSpecification)).append("\n");
    sb.append("    shipmentTracking: ").append(toIndentedString(shipmentTracking)).append("\n");
    sb.append("    shippingInstruction: ").append(toIndentedString(shippingInstruction)).append("\n");
    sb.append("    weight: ").append(toIndentedString(weight)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    referredType: ").append(toIndentedString(referredType)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

