package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@ApiModel(description="Definition of the nature of a Shipment. For example, could be a standard ground delivery, overnight express with signature required by an adult, etc.")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class ShipmentSpecification   {
  
  private String id = null;
  private String href = null;
  private String description = null;
  private Boolean isBundle = null;
  private Date lastUpdate = null;
  private String lifecycleStatus = null;
  private String name = null;
  private String version = null;
  private List<AttachmentRefOrValue> attachment = new ArrayList<AttachmentRefOrValue>();
  private List<ConstraintRef> constraint = new ArrayList<ConstraintRef>();
  private List<RelatedParty> relatedParty = new ArrayList<RelatedParty>();
  private List<ShipmentSpecificationRelationship> shipmentSpecRelationship = new ArrayList<ShipmentSpecificationRelationship>();
  private List<CharacteristicSpecification> shipmentSpecificationCharacteristic = new ArrayList<CharacteristicSpecification>();
  private TargetShipmentSchema targetShipmentSchema = null;
  private TimePeriod validFor = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * unique identifier
   **/
  
  @ApiModelProperty(value = "unique identifier")
  @JsonProperty("id")
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }

  /**
   * Hyperlink reference
   **/
  
  @ApiModelProperty(value = "Hyperlink reference")
  @JsonProperty("href")
  public String getHref() {
    return href;
  }
  public void setHref(String href) {
    this.href = href;
  }

  /**
   * Description of this REST resource
   **/
  
  @ApiModelProperty(example = "Airmail delivery", value = "Description of this REST resource")
  @JsonProperty("description")
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }

  /**
   * isBundle determines whether an ShipmentSpecification represents a single ShipmentSpecification (false), or a bundle of ShipmentSpecification (true).
   **/
  
  @ApiModelProperty(example = "true", value = "isBundle determines whether an ShipmentSpecification represents a single ShipmentSpecification (false), or a bundle of ShipmentSpecification (true).")
  @JsonProperty("isBundle")
  public Boolean isIsBundle() {
    return isBundle;
  }
  public void setIsBundle(Boolean isBundle) {
    this.isBundle = isBundle;
  }

  /**
   * Date and time of the last update of this REST resource
   **/
  
  @ApiModelProperty(example = "2020-11-20T08:00:00Z", value = "Date and time of the last update of this REST resource")
  @JsonProperty("lastUpdate")
  public Date getLastUpdate() {
    return lastUpdate;
  }
  public void setLastUpdate(Date lastUpdate) {
    this.lastUpdate = lastUpdate;
  }

  /**
   * Used to indicate the current lifecycle status of this catalog item
   **/
  
  @ApiModelProperty(example = "active", value = "Used to indicate the current lifecycle status of this catalog item")
  @JsonProperty("lifecycleStatus")
  public String getLifecycleStatus() {
    return lifecycleStatus;
  }
  public void setLifecycleStatus(String lifecycleStatus) {
    this.lifecycleStatus = lifecycleStatus;
  }

  /**
   * Name given to this REST resource
   **/
  
  @ApiModelProperty(example = "Shipment Spec", value = "Name given to this REST resource")
  @JsonProperty("name")
  public String getName() {
    return name;
  }
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Entity specification version
   **/
  
  @ApiModelProperty(example = "4.0.1", value = "Entity specification version")
  @JsonProperty("version")
  public String getVersion() {
    return version;
  }
  public void setVersion(String version) {
    this.version = version;
  }

  /**
   * Attachments that may be of relevance to this specification, such as picture, document, media  
   **/
  
  @ApiModelProperty(value = "Attachments that may be of relevance to this specification, such as picture, document, media  ")
  @JsonProperty("attachment")
  public List<AttachmentRefOrValue> getAttachment() {
    return attachment;
  }
  public void setAttachment(List<AttachmentRefOrValue> attachment) {
    this.attachment = attachment;
  }

  /**
   * This is a list of constraint references applied to this specification  
   **/
  
  @ApiModelProperty(value = "This is a list of constraint references applied to this specification  ")
  @JsonProperty("constraint")
  public List<ConstraintRef> getConstraint() {
    return constraint;
  }
  public void setConstraint(List<ConstraintRef> constraint) {
    this.constraint = constraint;
  }

  /**
   * Parties who manage or otherwise have an interest in this shipment specification
   **/
  
  @ApiModelProperty(value = "Parties who manage or otherwise have an interest in this shipment specification")
  @JsonProperty("relatedParty")
  public List<RelatedParty> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedParty> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * Relationship to another shipment specification, might be dependency, substitution, etc.  
   **/
  
  @ApiModelProperty(value = "Relationship to another shipment specification, might be dependency, substitution, etc.  ")
  @JsonProperty("shipmentSpecRelationship")
  public List<ShipmentSpecificationRelationship> getShipmentSpecRelationship() {
    return shipmentSpecRelationship;
  }
  public void setShipmentSpecRelationship(List<ShipmentSpecificationRelationship> shipmentSpecRelationship) {
    this.shipmentSpecRelationship = shipmentSpecRelationship;
  }

  /**
   * List of characteristics that the shipment can take
   **/
  
  @ApiModelProperty(value = "List of characteristics that the shipment can take")
  @JsonProperty("shipmentSpecificationCharacteristic")
  public List<CharacteristicSpecification> getShipmentSpecificationCharacteristic() {
    return shipmentSpecificationCharacteristic;
  }
  public void setShipmentSpecificationCharacteristic(List<CharacteristicSpecification> shipmentSpecificationCharacteristic) {
    this.shipmentSpecificationCharacteristic = shipmentSpecificationCharacteristic;
  }

  /**
   * Pointer to a schema that defines the target shipment
   **/
  
  @ApiModelProperty(value = "Pointer to a schema that defines the target shipment")
  @JsonProperty("targetShipmentSchema")
  public TargetShipmentSchema getTargetShipmentSchema() {
    return targetShipmentSchema;
  }
  public void setTargetShipmentSchema(TargetShipmentSchema targetShipmentSchema) {
    this.targetShipmentSchema = targetShipmentSchema;
  }

  /**
   * The period for which this REST resource is valid
   **/
  
  @ApiModelProperty(value = "The period for which this REST resource is valid")
  @JsonProperty("validFor")
  public TimePeriod getValidFor() {
    return validFor;
  }
  public void setValidFor(TimePeriod validFor) {
    this.validFor = validFor;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShipmentSpecification shipmentSpecification = (ShipmentSpecification) o;
    return Objects.equals(id, shipmentSpecification.id) &&
        Objects.equals(href, shipmentSpecification.href) &&
        Objects.equals(description, shipmentSpecification.description) &&
        Objects.equals(isBundle, shipmentSpecification.isBundle) &&
        Objects.equals(lastUpdate, shipmentSpecification.lastUpdate) &&
        Objects.equals(lifecycleStatus, shipmentSpecification.lifecycleStatus) &&
        Objects.equals(name, shipmentSpecification.name) &&
        Objects.equals(version, shipmentSpecification.version) &&
        Objects.equals(attachment, shipmentSpecification.attachment) &&
        Objects.equals(constraint, shipmentSpecification.constraint) &&
        Objects.equals(relatedParty, shipmentSpecification.relatedParty) &&
        Objects.equals(shipmentSpecRelationship, shipmentSpecification.shipmentSpecRelationship) &&
        Objects.equals(shipmentSpecificationCharacteristic, shipmentSpecification.shipmentSpecificationCharacteristic) &&
        Objects.equals(targetShipmentSchema, shipmentSpecification.targetShipmentSchema) &&
        Objects.equals(validFor, shipmentSpecification.validFor) &&
        Objects.equals(baseType, shipmentSpecification.baseType) &&
        Objects.equals(schemaLocation, shipmentSpecification.schemaLocation) &&
        Objects.equals(type, shipmentSpecification.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(id, href, description, isBundle, lastUpdate, lifecycleStatus, name, version, attachment, constraint, relatedParty, shipmentSpecRelationship, shipmentSpecificationCharacteristic, targetShipmentSchema, validFor, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShipmentSpecification {\n");
    
    sb.append("    id: ").append(toIndentedString(id)).append("\n");
    sb.append("    href: ").append(toIndentedString(href)).append("\n");
    sb.append("    description: ").append(toIndentedString(description)).append("\n");
    sb.append("    isBundle: ").append(toIndentedString(isBundle)).append("\n");
    sb.append("    lastUpdate: ").append(toIndentedString(lastUpdate)).append("\n");
    sb.append("    lifecycleStatus: ").append(toIndentedString(lifecycleStatus)).append("\n");
    sb.append("    name: ").append(toIndentedString(name)).append("\n");
    sb.append("    version: ").append(toIndentedString(version)).append("\n");
    sb.append("    attachment: ").append(toIndentedString(attachment)).append("\n");
    sb.append("    constraint: ").append(toIndentedString(constraint)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    shipmentSpecRelationship: ").append(toIndentedString(shipmentSpecRelationship)).append("\n");
    sb.append("    shipmentSpecificationCharacteristic: ").append(toIndentedString(shipmentSpecificationCharacteristic)).append("\n");
    sb.append("    targetShipmentSchema: ").append(toIndentedString(targetShipmentSchema)).append("\n");
    sb.append("    validFor: ").append(toIndentedString(validFor)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

