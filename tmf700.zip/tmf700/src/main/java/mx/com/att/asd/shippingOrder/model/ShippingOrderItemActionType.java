package mx.com.att.asd.shippingOrder.model;

public enum ShippingOrderItemActionType {
    add, modify, delete, noChange
}
