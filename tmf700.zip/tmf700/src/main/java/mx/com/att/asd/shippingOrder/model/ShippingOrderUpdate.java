package mx.com.att.asd.shippingOrder.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@ApiModel(description="A Shipping Order is a document used by a business to specify what items are to be transferred from a storage location or warehouse to which person and to which new location. A Shipping Order can typically be sent along with a shipment of goods so that the person receiving them can verify that the document correctly reflects the items that they actually received. Skipped properties: id,href,creationDate,lastUpdateDate")
@jakarta.annotation.Generated(value = "io.swagger.codegen.languages.JavaResteasyServerCodegen", date = "2024-07-19T14:23:40.334Z")
public class ShippingOrderUpdate   {
  
  private String status = null;
  private List<Note> note = new ArrayList<Note>();
  private RelatedPlaceRefOrValue placeFrom = null;
  private RelatedPlaceRefOrValue placeTo = null;
  private ProductOrderRef productOrder = null;
  private List<RelatedPartyWithContactInfo> relatedParty = new ArrayList<RelatedPartyWithContactInfo>();
  private RelatedShippingOrder relatedShippingOrder = null;
  private ShippingInstruction shippingInstruction = null;
  private List<Characteristic> shippingOrderCharacteristic = new ArrayList<Characteristic>();
  private List<ShippingOrderItem> shippingOrderItem = new ArrayList<ShippingOrderItem>();
  private ProductOfferingRef shippingOrderOffering = null;
  private ProductPrice shippingOrderPrice = null;
  private String baseType = null;
  private String schemaLocation = null;
  private String type = null;

  /**
   * status of shipping order e.g \&quot;active\&quot; , \&quot;savedForLater\&quot;
   **/
  
  @ApiModelProperty(example = "active", value = "status of shipping order e.g \"active\" , \"savedForLater\"")
  @JsonProperty("status")
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }

  /**
   * A list of notes made on this shipping shipment
   **/
  
  @ApiModelProperty(value = "A list of notes made on this shipping shipment")
  @JsonProperty("note")
  public List<Note> getNote() {
    return note;
  }
  public void setNote(List<Note> note) {
    this.note = note;
  }

  /**
   * Source location of the item. E.g. warehouse or shop location. The location can be specified at the shipping order level or at the shipping order item level if multiple sources are specified part of the same shipping order.
   **/
  
  @ApiModelProperty(value = "Source location of the item. E.g. warehouse or shop location. The location can be specified at the shipping order level or at the shipping order item level if multiple sources are specified part of the same shipping order.")
  @JsonProperty("placeFrom")
  public RelatedPlaceRefOrValue getPlaceFrom() {
    return placeFrom;
  }
  public void setPlaceFrom(RelatedPlaceRefOrValue placeFrom) {
    this.placeFrom = placeFrom;
  }

  /**
   * Destination of the item. E.g. customer home address. The location can be specified at the shipping order level or at the shipping order item level if multiple destinations are specified part of the same shipping order.
   **/
  
  @ApiModelProperty(value = "Destination of the item. E.g. customer home address. The location can be specified at the shipping order level or at the shipping order item level if multiple destinations are specified part of the same shipping order.")
  @JsonProperty("placeTo")
  public RelatedPlaceRefOrValue getPlaceTo() {
    return placeTo;
  }
  public void setPlaceTo(RelatedPlaceRefOrValue placeTo) {
    this.placeTo = placeTo;
  }

  /**
   * The product order for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product order for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("productOrder")
  public ProductOrderRef getProductOrder() {
    return productOrder;
  }
  public void setProductOrder(ProductOrderRef productOrder) {
    this.productOrder = productOrder;
  }

  /**
   * An existing related party that has some form of correlation with the given shipping order. It can be recipient, payer, etc.
   **/
  
  @ApiModelProperty(value = "An existing related party that has some form of correlation with the given shipping order. It can be recipient, payer, etc.")
  @JsonProperty("relatedParty")
  public List<RelatedPartyWithContactInfo> getRelatedParty() {
    return relatedParty;
  }
  public void setRelatedParty(List<RelatedPartyWithContactInfo> relatedParty) {
    this.relatedParty = relatedParty;
  }

  /**
   * An existing shipping order that has some form of correlation with the given shipping order
   **/
  
  @ApiModelProperty(value = "An existing shipping order that has some form of correlation with the given shipping order")
  @JsonProperty("relatedShippingOrder")
  public RelatedShippingOrder getRelatedShippingOrder() {
    return relatedShippingOrder;
  }
  public void setRelatedShippingOrder(RelatedShippingOrder relatedShippingOrder) {
    this.relatedShippingOrder = relatedShippingOrder;
  }

  /**
   * The product order for which the shipping order is created, if supplied as input the attribute id must be populated
   **/
  
  @ApiModelProperty(value = "The product order for which the shipping order is created, if supplied as input the attribute id must be populated")
  @JsonProperty("shippingInstruction")
  public ShippingInstruction getShippingInstruction() {
    return shippingInstruction;
  }
  public void setShippingInstruction(ShippingInstruction shippingInstruction) {
    this.shippingInstruction = shippingInstruction;
  }

  /**
   * List of characteristics with values
   **/
  
  @ApiModelProperty(value = "List of characteristics with values")
  @JsonProperty("shippingOrderCharacteristic")
  public List<Characteristic> getShippingOrderCharacteristic() {
    return shippingOrderCharacteristic;
  }
  public void setShippingOrderCharacteristic(List<Characteristic> shippingOrderCharacteristic) {
    this.shippingOrderCharacteristic = shippingOrderCharacteristic;
  }

  /**
   * A list of shipping order items. Each shipping order item has a corresponding Shipment(e.g. parcel) which has one or multiple products in it
   **/
  
  @ApiModelProperty(value = "A list of shipping order items. Each shipping order item has a corresponding Shipment(e.g. parcel) which has one or multiple products in it")
  @JsonProperty("shippingOrderItem")
  public List<ShippingOrderItem> getShippingOrderItem() {
    return shippingOrderItem;
  }
  public void setShippingOrderItem(List<ShippingOrderItem> shippingOrderItem) {
    this.shippingOrderItem = shippingOrderItem;
  }

  /**
   * Shipping order can have a corresponding entry in the product catalog (product offering)
   **/
  
  @ApiModelProperty(value = "Shipping order can have a corresponding entry in the product catalog (product offering)")
  @JsonProperty("shippingOrderOffering")
  public ProductOfferingRef getShippingOrderOffering() {
    return shippingOrderOffering;
  }
  public void setShippingOrderOffering(ProductOfferingRef shippingOrderOffering) {
    this.shippingOrderOffering = shippingOrderOffering;
  }

  /**
   * Shipping Order price
   **/
  
  @ApiModelProperty(value = "Shipping Order price")
  @JsonProperty("shippingOrderPrice")
  public ProductPrice getShippingOrderPrice() {
    return shippingOrderPrice;
  }
  public void setShippingOrderPrice(ProductPrice shippingOrderPrice) {
    this.shippingOrderPrice = shippingOrderPrice;
  }

  /**
   * When sub-classing, this defines the super-class
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the super-class")
  @JsonProperty("@baseType")
  public String getBaseType() {
    return baseType;
  }
  public void setBaseType(String baseType) {
    this.baseType = baseType;
  }

  /**
   * A URI to a JSON-Schema file that defines additional attributes and relationships
   **/
  
  @ApiModelProperty(value = "A URI to a JSON-Schema file that defines additional attributes and relationships")
  @JsonProperty("@schemaLocation")
  public String getSchemaLocation() {
    return schemaLocation;
  }
  public void setSchemaLocation(String schemaLocation) {
    this.schemaLocation = schemaLocation;
  }

  /**
   * When sub-classing, this defines the sub-class Extensible name
   **/
  
  @ApiModelProperty(value = "When sub-classing, this defines the sub-class Extensible name")
  @JsonProperty("@type")
  public String getType() {
    return type;
  }
  public void setType(String type) {
    this.type = type;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ShippingOrderUpdate shippingOrderUpdate = (ShippingOrderUpdate) o;
    return Objects.equals(status, shippingOrderUpdate.status) &&
        Objects.equals(note, shippingOrderUpdate.note) &&
        Objects.equals(placeFrom, shippingOrderUpdate.placeFrom) &&
        Objects.equals(placeTo, shippingOrderUpdate.placeTo) &&
        Objects.equals(productOrder, shippingOrderUpdate.productOrder) &&
        Objects.equals(relatedParty, shippingOrderUpdate.relatedParty) &&
        Objects.equals(relatedShippingOrder, shippingOrderUpdate.relatedShippingOrder) &&
        Objects.equals(shippingInstruction, shippingOrderUpdate.shippingInstruction) &&
        Objects.equals(shippingOrderCharacteristic, shippingOrderUpdate.shippingOrderCharacteristic) &&
        Objects.equals(shippingOrderItem, shippingOrderUpdate.shippingOrderItem) &&
        Objects.equals(shippingOrderOffering, shippingOrderUpdate.shippingOrderOffering) &&
        Objects.equals(shippingOrderPrice, shippingOrderUpdate.shippingOrderPrice) &&
        Objects.equals(baseType, shippingOrderUpdate.baseType) &&
        Objects.equals(schemaLocation, shippingOrderUpdate.schemaLocation) &&
        Objects.equals(type, shippingOrderUpdate.type);
  }

  @Override
  public int hashCode() {
    return Objects.hash(status, note, placeFrom, placeTo, productOrder, relatedParty, relatedShippingOrder, shippingInstruction, shippingOrderCharacteristic, shippingOrderItem, shippingOrderOffering, shippingOrderPrice, baseType, schemaLocation, type);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ShippingOrderUpdate {\n");
    
    sb.append("    status: ").append(toIndentedString(status)).append("\n");
    sb.append("    note: ").append(toIndentedString(note)).append("\n");
    sb.append("    placeFrom: ").append(toIndentedString(placeFrom)).append("\n");
    sb.append("    placeTo: ").append(toIndentedString(placeTo)).append("\n");
    sb.append("    productOrder: ").append(toIndentedString(productOrder)).append("\n");
    sb.append("    relatedParty: ").append(toIndentedString(relatedParty)).append("\n");
    sb.append("    relatedShippingOrder: ").append(toIndentedString(relatedShippingOrder)).append("\n");
    sb.append("    shippingInstruction: ").append(toIndentedString(shippingInstruction)).append("\n");
    sb.append("    shippingOrderCharacteristic: ").append(toIndentedString(shippingOrderCharacteristic)).append("\n");
    sb.append("    shippingOrderItem: ").append(toIndentedString(shippingOrderItem)).append("\n");
    sb.append("    shippingOrderOffering: ").append(toIndentedString(shippingOrderOffering)).append("\n");
    sb.append("    shippingOrderPrice: ").append(toIndentedString(shippingOrderPrice)).append("\n");
    sb.append("    baseType: ").append(toIndentedString(baseType)).append("\n");
    sb.append("    schemaLocation: ").append(toIndentedString(schemaLocation)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

