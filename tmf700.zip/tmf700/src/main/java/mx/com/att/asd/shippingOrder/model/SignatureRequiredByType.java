package mx.com.att.asd.shippingOrder.model;

public enum SignatureRequiredByType {
    adult, receiver
}
