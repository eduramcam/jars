package mx.com.att.asd.shippingOrder.util;

public record ApiOperationProps(String value, String note, String response, String method) {}
