package mx.com.att.asd.shippingOrder.util;

public record ApiResponseProps(String code, String message, String responseClass,String responseContainer) {}
