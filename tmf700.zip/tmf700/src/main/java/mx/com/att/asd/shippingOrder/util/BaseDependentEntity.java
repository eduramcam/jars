package mx.com.att.asd.shippingOrder.util;

import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
import jakarta.persistence.Column;
import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@MappedSuperclass
public class BaseDependentEntity extends PanacheEntityBase {
  @Id
  @Column(name = "internal_id")
  protected String internalId;

  @Column(name = "aggregate_id")
  protected String aggregateId;

  @Column(name = "parent_id")
  protected String parentId;
}
