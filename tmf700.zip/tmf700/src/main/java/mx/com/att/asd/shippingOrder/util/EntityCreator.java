package mx.com.att.asd.shippingOrder.util;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.SOURCE)
@Target(ElementType.TYPE)
public @interface EntityCreator {
    String value();

    boolean isSubEntity();

    String propertyName();
}
