package mx.com.att.asd.shippingOrder.util;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.Types;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SupportedAnnotationTypes({"mx.com.att.asd.shippingOrder.util.EntityCreator"})
@SupportedSourceVersion(SourceVersion.RELEASE_21)
public class EntityCreatorProcessor extends AbstractProcessor {
    public static final String QUERY_HELPER_TEMPLATE =
            """
                        package %s;//package
                        import mx.com.att.asd.shippingOrder.entities.ProductOrderEntity;
                        import com.comviva.pacs.query.Aggregate;
                        import com.comviva.pacs.query.AggregateBuilder;

                        public class %sQueryServiceHelper {
                            public final Aggregate aggregate;

                            public %sQueryServiceHelper() {

                                %s //child definitions

                                this.aggregate = AggregateBuilder.anAggregate()
                                        .withName("%s")
                                        .withJpaEntity(%s)
                                         %s//children
                                        .build();
                            }
                        }
                    """;
    public static final String MAPPER_CLASS_TEMPLATE =
            """
                          package %s;//package

                          import %s;//entity import
                          import %s;//model import
                          import %s;//model Extender import
                          import java.util.Set;
                          import org.mapstruct.AfterMapping;
                          import org.mapstruct.Mapper;
                          import org.mapstruct.Mapping;
                          import org.mapstruct.Context;
                          import org.mapstruct.MappingTarget;

                          public interface %s {
                            %s
                            %s modelToEntity(%s model);
                            %s
                            %s entityToModel(%s entity, @Context Set<String> fields);

                            @AfterMapping
                            default %s cloneWithAllowedFields(@MappingTarget %s model, @Context Set<String> allowedFields) {
                              if(allowedFields==null || allowedFields.contains("*")) return model;
                              if(allowedFields.isEmpty()) return new %s();
                              if(!"%s".isEmpty()){
                                if(allowedFields.contains("%s") && allowedFields.size()==1) return model;
                              }
                              return new %sExtender().cloneWithAllowedFields(model, allowedFields);
                            }
                          }
                    """;
    public static final String ENTITY_CLASS_TEMPLATE =
            """
                        package %s;

                        import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
                        import jakarta.persistence.Column;
                        import jakarta.persistence.Entity;
                        import jakarta.persistence.Id;
                        import jakarta.persistence.Table;
                        import lombok.Getter;
                        import lombok.Setter;

                        import java.time.OffsetDateTime;
                        import java.util.List;

                        @Entity
                        @Table(name = "%s")
                        @Getter
                        @Setter
                        public class %s  extends PanacheEntityBase{
                          %s
                        }
                    """;
    public static final String SUB_ENTITY_CLASS_TEMPLATE =
            """
                        package %s;

                        import io.quarkus.hibernate.orm.panache.PanacheEntityBase;
                        import jakarta.persistence.Column;
                        import jakarta.persistence.Entity;
                        import jakarta.persistence.Id;
                        import jakarta.persistence.Table;
                        import lombok.Getter;
                        import lombok.Setter;

                        import java.time.OffsetDateTime;
                        import java.util.List;

                        import mx.com.att.asd.shippingOrder.util.BaseDependentEntity;

                        @Entity
                        @Table(name = "%s")
                        @Getter
                        @Setter
                        public class %s  extends BaseDependentEntity{
                          %s

                          public static List<%s> findByAggregateId(String aggregateId) {
                            return list("aggregateId", aggregateId);
                          }

                          public static List<%s> findByAggregateIdIn(List<String> aggregateIdList) {
                            return list("aggregateId in (?1)", aggregateIdList);
                          }
                        }
                    """;

    private Types typeUtils;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnv) {
        super.init(processingEnv);
        typeUtils = processingEnv.getTypeUtils();
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        for (Element e : roundEnv.getElementsAnnotatedWith(EntityCreator.class)) {
            TypeElement typeElement = (TypeElement) e;
            var annotation = typeElement.getAnnotation(EntityCreator.class);
            try {
                if (annotation.isSubEntity()) {
                    createSubEntity(typeElement, annotation.value());
                } else {
                    createEntity(typeElement, annotation.value());
                }
                createMapper(typeElement, annotation.value(), annotation.propertyName());
            } catch (IOException | ClassNotFoundException ex) {
                throw new RuntimeException(ex);
            }
        }
        return false;
    }

    private void createSubEntity(TypeElement classElement, String entityName)
            throws IOException, ClassNotFoundException {
        var qualifiedName = classElement.getQualifiedName().toString();
        var packageName = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
        packageName = packageName.substring(0, packageName.lastIndexOf(".")) + ".entities";
        String sourceCode = generateSourceCode(packageName, entityName, classElement, true);
        if (sourceCode.contains("BaseDependentEntity") && sourceCode.contains("@Id")) {
            sourceCode = sourceCode.replace("@Id", "");
        }
        try (PrintWriter writer = new PrintWriter(processingEnv
                .getFiler()
                .createSourceFile(packageName + "." + entityName, classElement)
                .openWriter())) {
            writer.print(sourceCode);
        }
    }

    private void createEntity(TypeElement classElement, String entityName) throws IOException, ClassNotFoundException {
        var qualifiedName = classElement.getQualifiedName().toString();
        var packageName = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
        packageName = packageName.substring(0, packageName.lastIndexOf(".")) + ".entities";
        String sourceCode = generateSourceCode(packageName, entityName, classElement, false);
        try (PrintWriter writer = new PrintWriter(processingEnv
                .getFiler()
                .createSourceFile(packageName + "." + entityName, classElement)
                .openWriter())) {
            writer.print(sourceCode);
        }
    }

    private void createMapper(TypeElement classElement, String entityName, String propertyName) throws IOException {
        var qualifiedName = classElement.getQualifiedName().toString();
        var basePackage = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
        basePackage = basePackage.substring(0, basePackage.lastIndexOf("."));
        var mapperPackage = basePackage + ".mappers";
        var entityPackage = basePackage + ".entities";
        var modelPackage = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
        var modelName = classElement.getSimpleName().toString();

        String sourceCode = generateMapperSourceCode(
                mapperPackage, entityName, entityPackage, modelName, modelPackage, classElement, propertyName);
        try (PrintWriter writer = new PrintWriter(processingEnv
                .getFiler()
                .createSourceFile(mapperPackage + "." + modelName + "MapperBase", classElement)
                .openWriter())) {
            writer.print(sourceCode);
        }
    }

    private String removeUnderscoreFromStart(String input) {
        if (input != null && input.startsWith("_")) {
            return input.substring(1);
        }
        return input;
    }

    private String generateSourceCode(
            String packageName, String simpleClassName, TypeElement classElement, boolean isSubEntity)
            throws ClassNotFoundException {
        String tableName =
                simpleClassName.replaceAll("(.)(\\p{Upper})", "$1_$2").toLowerCase();
        var fields = classElement.getEnclosedElements().stream()
                .filter(el -> el.getKind().equals(ElementKind.FIELD))
                .map(el -> (VariableElement) el)
                .filter(el -> !el.asType().toString().startsWith("java.util.List"))
                .map(el -> {
                    try {
                        return elementToField(el, "", "");
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n\t"));

        var superClass = typeMirrorToClass(classElement.getSuperclass());
        var elementName = classElement.getSimpleName().toString();
        if (superClass != null
            && !superClass.toString().contains("Enum")
            && superClass.toString().startsWith("class com.")) {
            System.out.println("sssssssssss " + superClass + " " + classElement.getSimpleName());
            var extendedFields = Stream.of(superClass.getDeclaredFields())
                    .map(e -> {
                        System.out.println("subClassField " + e.getName());
                        return e;
                    })
                    .map(e -> "%s\n@Column(name = \"%s_%s\")\n\tprivate %s %s%s;"
                            .formatted(
                                    removeUnderscoreFromStart(e.getName()).equals("id") ? "@Id" : "",
                                    toSnakeCase(elementName),
                                    toSnakeCase(removeUnderscoreFromStart(e.getName())),
                                    e.getType().toString().substring(6),
                                    elementName,
                                    capitalize(removeUnderscoreFromStart(e.getName()))))
                    .collect(Collectors.joining("\n\t"));
            fields = fields + "\n\t" + extendedFields;
        }

        return (isSubEntity ? SUB_ENTITY_CLASS_TEMPLATE : ENTITY_CLASS_TEMPLATE)
                .formatted(packageName, tableName, simpleClassName, fields, simpleClassName, simpleClassName);
    }

    private String generateQueryHelperSourceCode(String packageName, String simpleClassName, TypeElement classElement) {
        String beanName = classElement.getSimpleName().toString();
        String entityClass = "mx.com.att.asd.shippingOrder.entities." + simpleClassName + ".class";
        return QUERY_HELPER_TEMPLATE.formatted(packageName, beanName, beanName, "", beanName, entityClass, "");
    }

    private String generateMapperSourceCode(
            String packageName,
            String entityName,
            String entityPackage,
            String modelName,
            String modelPackage,
            TypeElement classElement,
            String propertyName) {
        var mappingsForModelToEntity = classElement.getEnclosedElements().stream()
                .filter(el -> el.getKind().equals(ElementKind.FIELD))
                .map(el -> (VariableElement) el)
                .filter(el -> !el.asType().toString().startsWith("java."))
                .map(el -> {
                    try {
                        return elementToMapping(el, "", false, "");
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n\t"));
        var mappingsForEntityToModel = classElement.getEnclosedElements().stream()
                .filter(el -> el.getKind().equals(ElementKind.FIELD))
                .map(el -> (VariableElement) el)
                .filter(el -> !el.asType().toString().startsWith("java."))
                .map(el -> {
                    try {
                        return elementToMapping(el, "", true, "");
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n\t"));
        return MAPPER_CLASS_TEMPLATE.formatted(
                packageName,
                entityPackage + "." + entityName,
                modelPackage + "." + modelName,
                modelPackage + "." + modelName + "Extender",
                modelName + "MapperBase",
                mappingsForModelToEntity,
                entityName,
                modelName,
                mappingsForEntityToModel,
                modelName,
                entityName,
                modelName,
                modelName,
                modelName,
                propertyName,
                propertyName,
                modelName);
    }

    private String elementToMapping1(Field field, String prefix, boolean reverse) throws ClassNotFoundException {
        String template = "\t@Mapping(source = \"%s\",target = \"%s\")%n";
        var source = field.getName();
        var target = field.getName();
        if (source.startsWith("_at")) {
            source = source.substring(1);
        }
        if (target.startsWith("_at")) {
            target = target.substring(1);
        }

        if (field.getType().toString().startsWith("java.")
            || field.getType().toString().startsWith("class java.")) {
            target = prefix + capitalize(target);
            return reverse
                    ? template.formatted(target, prefix + "." + source)
                    : template.formatted(prefix + "." + source, target);
        }
        var sourceFinal = source;
        var fields = Stream.of(field.getType().getDeclaredFields())
                .filter(el -> !el.getType().toString().startsWith("java.util.List"))
                .map(el -> {
                    try {
                        return elementToMapping1(el, sourceFinal, reverse);
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n"));
        var subTypeClass = field.getType();
        if (subTypeClass.getSuperclass() != null
            && !subTypeClass.getSuperclass().toString().contains("Enum")) {
            var superClass = subTypeClass.getSuperclass();
            var extendedFields = List.of(superClass.getDeclaredFields()).stream()
                    .map(el -> {
                        try {
                            return elementToMapping1(el, sourceFinal, reverse);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                    })
                    .collect(Collectors.joining("\n\t"));
            fields = fields + "\n\t" + extendedFields;
        }
        return fields;
    }

    private String elementToMapping(VariableElement variableElement, String prefix, boolean reverse,
                                    String parentPrefix)
            throws ClassNotFoundException {
        String parentPrefixWithDot = parentPrefix.isBlank() ? "" : parentPrefix + ".";
        String template = "\t@Mapping(source = \"%s%s\",target = \"%s%s\")%n";
        var source = variableElement.getSimpleName().toString();
        var target = variableElement.getSimpleName().toString();
        if (source.startsWith("_at")) {
            source = source.substring(1);
        }
        if (target.startsWith("_at")) {
            target = target.substring(1);
        }
        if (variableElement.asType().toString().startsWith("java.")) {
            target = prefix + capitalize(target);
            return reverse
                    ? template.formatted(parentPrefix, target, parentPrefixWithDot, prefix + "." + source)
                    : template.formatted(parentPrefixWithDot, prefix + "." + source, parentPrefix, target);
        }
        var subType = processingEnv.getTypeUtils().asElement(variableElement.asType());
        var subTypeClass = typeMirrorToClass(variableElement.asType());
        var sourceFinal = source;
        var fields = subType.getEnclosedElements().stream()
                .filter(el -> el.getKind().equals(ElementKind.FIELD))
                .map(el -> (VariableElement) el)
                .filter(el -> !el.asType().toString().startsWith("java.util.List"))
                .map(el -> {
                    try {
                        return elementToMapping(el, sourceFinal, reverse, prefix);
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n"));
        if (subTypeClass.getSuperclass() != null
            && !subTypeClass.getSuperclass().toString().contains("Enum")) {
            var superClass = subTypeClass.getSuperclass();
            var extendedFields = List.of(superClass.getDeclaredFields()).stream()
                    .map(el -> {
                        try {
                            return elementToMapping1(el, sourceFinal, reverse);
                        } catch (ClassNotFoundException e) {
                            throw new RuntimeException(e);
                        }
                    })
                    .collect(Collectors.joining("\n\t"));
            fields = fields + "\n\t" + extendedFields;
        }
        return fields;
    }

    private String elementToField(VariableElement variableElement, String prefix, String parentPrefix) throws ClassNotFoundException {
        if (variableElement.asType().toString().startsWith("java.")) {
            var columnNamePrefix = prefix.isBlank() ? "" : toSnakeCase(prefix) + "_";
            var fieldName = prefix.isBlank()
                    ? variableElement.getSimpleName().toString()
                    : capitalize(variableElement.getSimpleName().toString());
            if (fieldName.startsWith("_")) {
                fieldName = capitalize(fieldName.substring(1));
            }
            return "%s\n@Column(name = \"%s%s\")\n\tprivate %s %s%s%s;"
                    .formatted(
                            variableElement.getSimpleName().toString().equals("id") && prefix.isBlank() ? "@Id" : "",
                            columnNamePrefix,
                            toSnakeCase(variableElement.getSimpleName().toString()),
                            variableElement.asType().toString(),
                            parentPrefix,
                            prefix,
                            fieldName);
        }

        var subType = processingEnv.getTypeUtils().asElement(variableElement.asType());
        var subTypeClass = typeMirrorToClass(variableElement.asType());
        var elementName = variableElement.getSimpleName().toString();
        var fields = subType.getEnclosedElements().stream()
                .filter(el -> el.getKind().equals(ElementKind.FIELD))
                .map(el -> (VariableElement) el)
                .filter(el -> !el.asType().toString().startsWith("java.util.List"))
                .map(el -> {
                    try {
                        return elementToField(el, elementName, prefix);
                    } catch (ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                })
                .collect(Collectors.joining("\n"));
        var superClass = subTypeClass.getSuperclass();
        if (superClass != null
            && !superClass.toString().contains("Enum")
            && superClass.toString().startsWith("class com.")) {
            System.out.println("subclassss " + subTypeClass.getSuperclass() + " " + elementName);
            var extendedFields = Stream.of(superClass.getDeclaredFields())
                    .map(e -> {
                        System.out.println("subClassField " + e.getName());
                        return e;
                    })
                    .map(e -> "%s\n@Column(name = \"%s_%s\")\n\tprivate %s %s%s;"
                            .formatted(
                                    removeUnderscoreFromStart(e.getName()).equals("id") ? "@Id" : "",
                                    toSnakeCase(elementName),
                                    toSnakeCase(removeUnderscoreFromStart(e.getName())),
                                    e.getType().toString().substring(6),
                                    elementName,
                                    capitalize(removeUnderscoreFromStart(e.getName()))))
                    .collect(Collectors.joining("\n\t"));
            fields = fields + "\n\t" + extendedFields;
        }
        return fields;
    }

    private String toSnakeCase(String key) {
        return key.replaceAll("(.)(\\p{Upper})", "$1_$2").toLowerCase();
    }

    private String capitalize(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

    private Class<?> typeMirrorToClass(TypeMirror typeMirror) throws ClassNotFoundException {
        if (typeMirror == null) {
            return null;
        }

        TypeElement typeElement = (TypeElement) typeUtils.asElement(typeMirror);
        if (typeElement == null) {
            return null;
        }

        String className = typeElement.getQualifiedName().toString();
        return Class.forName(className);
    }
}
