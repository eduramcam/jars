package mx.com.att.asd.shippingOrder.util;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.PATCH;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Messager;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.ExecutableElement;
import javax.lang.model.element.PackageElement;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.MirroredTypeException;
import javax.lang.model.type.TypeMirror;
import javax.tools.Diagnostic;
import javax.tools.StandardLocation;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@SupportedAnnotationTypes({"mx.com.att.asd.shippingOrder.util.ModelExtender"})
@SupportedSourceVersion(SourceVersion.RELEASE_21)
public class ModelExtenderProcessor extends AbstractProcessor {
    private static final Pattern API_PATTERN = Pattern.compile("@io.swagger.annotations.Api\\([^)]*\\)");
    private static final Pattern API_PATTERN1 = Pattern.compile("@Api\\([^)]*\\)");
    private static final Pattern API_RESPONSES_PATTERN = Pattern.compile("@io.swagger.annotations.ApiResponses\\(");
    private static final Pattern API_RESPONSES_PATTERN1 = Pattern.compile("@ApiResponses\\(");
    private static final Pattern API_RESPONSE_PATTERN =
            Pattern.compile("@io.swagger.annotations.ApiResponse\\([^)]*\\)");
    private static final Pattern API_RESPONSE_PATTERN1 = Pattern.compile("@ApiResponse\\([^)]*\\)");
    private static final Pattern API_OPERATION_PATTERN =
            Pattern.compile("@io.swagger.annotations.ApiOperation\\([^)]*\\)(?!\")");
    private static final Pattern API_OPERATION_PATTERN1 = Pattern.compile("@ApiOperation\\([^)]*\\)(?!\")");
    private static final Pattern CLASS_NAME_PATTERN = Pattern.compile("public\\s+class\\s+\\w+\\s*\\{");
    private static final Pattern PACKAGE_PATTERN = Pattern.compile("package\\s[^;]*;");

    private static final String RESOURCE_CLASS_HEADER_TEMPLATE =
            """
                    %s
                    import jakarta.ws.rs.core.MediaType;
                    import org.eclipse.microprofile.openapi.annotations.Operation;
                    import org.eclipse.microprofile.openapi.annotations.enums.ParameterIn;
                    import org.eclipse.microprofile.openapi.annotations.enums.SchemaType;
                    import org.eclipse.microprofile.openapi.annotations.headers.Header;
                    import org.eclipse.microprofile.openapi.annotations.media.Content;
                    import org.eclipse.microprofile.openapi.annotations.media.ExampleObject;
                    import org.eclipse.microprofile.openapi.annotations.media.Schema;
                    import org.eclipse.microprofile.openapi.annotations.parameters.Parameter;
                    import org.eclipse.microprofile.openapi.annotations.parameters.Parameters;
                    import org.eclipse.microprofile.openapi.annotations.parameters.RequestBody;
                    import org.eclipse.microprofile.openapi.annotations.responses.APIResponse;
                    import org.eclipse.microprofile.openapi.annotations.responses.APIResponses;
                    import org.eclipse.microprofile.openapi.annotations.security.SecurityRequirement;
                    import org.eclipse.microprofile.openapi.annotations.tags.Tag;
                    import org.eclipse.microprofile.openapi.annotations.tags.Tags;
                    """;

    private static final String CLASS_NAME_REPLACEMENT_TEMPLATE = "public class %s {";
    public static final String EXTENDER_CLASS_TEMPLATE =
            """
                        package %s;

                        import java.util.Set;
                        import jakarta.enterprise.context.ApplicationScoped;

                        @ApplicationScoped
                        public class %sExtender {
                          public %s cloneWithAllowedFields(%s original,Set<String> allowedFields){
                            if (allowedFields == null ||allowedFields.contains("*"))
                                return original;
                            var clone = new %s();
                            if(allowedFields.isEmpty()){
                               return clone;
                            }
                            allowedFields.forEach(field -> {
                      %s
                            });
                            return clone;
                          }
                        }
                    """;

    public static final String CASE_BLOCK_TEMPLATE =
            """
                              case "%s":
                                clone.set%s(original.get%s());
                              break;
                    """;
    public static final String ALTERNATE_CASE_BLOCK_TEMPLATE =
            """
                              case "%s":
                                clone.set%s(original.is%s());
                              break;
                    """;
    public static final String API_RESPONSE_TEMPLATE =
            """
                    @APIResponse(name = "%s",responseCode = "%s",content =@Content(mediaType = MediaType.APPLICATION_JSON,schema = @Schema(implementation = %s.class)))""";
    public static final String API_LIST_RESPONSE_TEMPLATE =
            """
                    @APIResponse(name = "%s",responseCode = "%s",content =@Content(mediaType = MediaType.APPLICATION_JSON,schema = @Schema(implementation = %s.class,type = SchemaType.ARRAY)))""";

    private static final String OPERATION_TEMPLATE =
            """
                    @Operation(
                        operationId = "%s",
                        summary = "%s.")
                    %s
                        """;

    private static final String TAGS_TEMPLATE =
            """
                    @Tags(value={@Tag(name="%s Read"),@Tag(name="%s Write")})""";
    private static final String TAG_TEMPLATE = """
              @Tag(ref = "%s %s")
            """;

    private String generateSourceCode(
            String packageName, String modelClassName, String simpleClassName, TypeElement classElement) {

        var caseBlocks = createCaseBlocks(modelClassName, classElement).toString();

        return EXTENDER_CLASS_TEMPLATE.formatted(
                packageName, simpleClassName, simpleClassName, modelClassName, modelClassName, caseBlocks);
    }

    private Stream<PackageElement> packageNameToPackageElements(String packageName) {
        return processingEnv.getElementUtils().getAllPackageElements(packageName).stream()
                .map(e -> (PackageElement) e);
    }

    private Stream<Element> allClassElementsInPackage(PackageElement packageElement) {
        return packageElement.getEnclosedElements().stream()
                .map(e -> (Element) e)
                .filter(el -> el.getKind() == ElementKind.CLASS);
    }

    private String modelExtenderToClassName(ModelExtender modelExtender) {
        var typeMirror = getTypeMirror(modelExtender);
        return typeMirror != null ? typeMirror.toString() : "";
    }

    private String classNameToPackageName(String className) {
        return className.substring(0, className.lastIndexOf("."));
    }

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        List<TypeElement> classElements = roundEnv.getElementsAnnotatedWith(ModelExtender.class).stream()
                .filter(element -> element.getKind() == ElementKind.INTERFACE)
                .map(TypeElement.class::cast)
                .map(typeElement -> typeElement.getAnnotation(ModelExtender.class))
                .map(this::modelExtenderToClassName)
                .map(this::classNameToPackageName)
                .flatMap(this::packageNameToPackageElements)
                .flatMap(this::allClassElementsInPackage)
                .map(el -> (TypeElement) el)
                .toList();

        try {
            Messager messager = processingEnv.getMessager();
            for (var classElement : classElements) {
                if (classElement.getSimpleName().toString().equalsIgnoreCase("ApiInfo")
                    || classElement.getSimpleName().toString().equalsIgnoreCase("ApiDescription")
                    || classElement.getSimpleName().toString().equalsIgnoreCase("ApiOperation")) {
                    continue;
                }
                var className = classElement.getSimpleName().toString();
                if (className.contains("Api")) {
                    messager.printMessage(
                            Diagnostic.Kind.NOTE, "Creating Resource for " + classElement.getQualifiedName());
                    createResource(classElement);
                } else {
                    messager.printMessage(
                            Diagnostic.Kind.NOTE, "Creating Extender for " + classElement.getQualifiedName());
                    createExtender(classElement);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    private StringBuilder createCaseBlocks(String interfaceName, TypeElement classElement) {
        processingEnv.getElementUtils().getTypeElement(interfaceName);

        var cases = new StringBuilder("switch(field){\n");
        boolean idPresent = false;
        for (Element enclosedElement : classElement.getEnclosedElements()) {
            if (enclosedElement.getKind() == ElementKind.FIELD) {
                VariableElement fieldElement = (VariableElement) enclosedElement;
                String fieldName = fieldElement.getSimpleName().toString();
                if (fieldName.startsWith("_at")) {
                    fieldName = fieldName.substring(1);
                }
                if (fieldName.equals("id")) {
                    idPresent = true;
                }
                String fieldType = fieldElement.asType().toString();
                String capitalized = capitalize(fieldName);
                if (fieldType.contains("Boolean")) {
                    cases.append(ALTERNATE_CASE_BLOCK_TEMPLATE.formatted(fieldName, capitalized, capitalized));
                } else {
                    cases.append(CASE_BLOCK_TEMPLATE.formatted(fieldName, capitalized, capitalized));
                }
            }
        }
        cases.append("\n}");
        if (!idPresent) return cases;
        var newBuilder = new StringBuilder("clone.setId(original.getId());\n");
        newBuilder.append(cases);
        return newBuilder;
    }

    private String getApiDescription(Element classElement) {
        var annotation = classElement.getAnnotation(Api.class);
        return annotation != null ? annotation.description() : "";
    }

    private String getBasePath(Element classElement) {
        var annotation = classElement.getAnnotation(Path.class);
        return annotation != null ? annotation.value() : "";
    }

    private ApiOperationProps getApiOperation(Element element) {
        System.out.println("element " + element.getSimpleName());
        var annotation = element.getAnnotation(ApiOperation.class);
        System.out.println("annotaton " + annotation);
        String responseClassName = getTypeMirror(annotation);
        String method = "GET";
        if (element.getAnnotation(POST.class) != null) method = "POST";
        else if (element.getAnnotation(DELETE.class) != null) method = "DELETE";
        else if (element.getAnnotation(PUT.class) != null) method = "PUT";
        else if (element.getAnnotation(PATCH.class) != null) method = "PATCH";
        return new ApiOperationProps(annotation.value(), annotation.notes(), responseClassName, method);
    }

    private List<ApiResponseProps> getApiResponses(Element element) {
        var annotation = element.getAnnotation(ApiResponses.class);
        if (annotation.value() != null && annotation.value().length > 0) {
            var responses = new ArrayList<ApiResponseProps>();
            for (var responseAnnotation : annotation.value()) {
                String className = getTypeMirror(responseAnnotation).toString();
                responses.add(new ApiResponseProps(
                        "" + responseAnnotation.code(),
                        responseAnnotation.message(),
                        className,
                        responseAnnotation.responseContainer()));
            }

            return responses;
        } else {
            return List.of(new ApiResponseProps("200", "", null, null));
        }
    }

    private void createResource(TypeElement classElement) {
        var simpleName = classElement.getSimpleName().toString();
        String apiDescription = getApiDescription(classElement);
        var methodProps = new ArrayList<ApiMethodProps>();
        for (Element enclosedElement : classElement.getEnclosedElements()) {
            if (enclosedElement.getKind() == ElementKind.METHOD) {
                ExecutableElement method = (ExecutableElement) enclosedElement;
                methodProps.add(
                        new ApiMethodProps(getBasePath(method), getApiOperation(method), getApiResponses(method)));
            }
        }
        String packageName = classElement
                .getQualifiedName()
                .toString()
                .substring(0, classElement.getQualifiedName().toString().lastIndexOf("."));
        try {
            var fo = processingEnv
                    .getFiler()
                    .getResource(StandardLocation.SOURCE_PATH, packageName, simpleName + ".java");
            var reader = fo.openReader(false);
            String code;
            try (var fileReader = new BufferedReader(reader)) {
                code = fileReader.lines().collect(Collectors.joining("\n"));
                code = code.replaceFirst("@Path", "//@Path(");
            }

            code = CLASS_NAME_PATTERN
                    .matcher(code)
                    .replaceFirst(CLASS_NAME_REPLACEMENT_TEMPLATE.formatted(simpleName + "Resource"));
            code = API_PATTERN.matcher(code).replaceFirst(TAGS_TEMPLATE.formatted(apiDescription, apiDescription));
            code = API_PATTERN1.matcher(code).replaceFirst(TAGS_TEMPLATE.formatted(apiDescription, apiDescription));
            code = API_RESPONSES_PATTERN.matcher(code).replaceAll("@APIResponses(");
            code = API_RESPONSES_PATTERN1.matcher(code).replaceAll("@APIResponses(");
            for (var methodProp : methodProps) {
                System.out.println("operation " + methodProp.operation().method());
                var isReadOperation =
                        "GET".equalsIgnoreCase(methodProp.operation().method());
                var tag = TAG_TEMPLATE.formatted(apiDescription, isReadOperation ? "Read" : "Write");
                code = API_OPERATION_PATTERN
                        .matcher(code)
                        .replaceFirst(OPERATION_TEMPLATE.formatted(
                                methodProp.operation().value(),
                                methodProp.operation().note(),
                                tag));
                code = API_OPERATION_PATTERN1
                        .matcher(code)
                        .replaceFirst(OPERATION_TEMPLATE.formatted(
                                methodProp.operation().value(),
                                methodProp.operation().note(),
                                tag));

                for (var resp : methodProp.responses()) {
                    String respAnnotation = resp.responseContainer() != null
                                            && resp.responseContainer().equalsIgnoreCase("List")
                            ? String.format(
                            API_LIST_RESPONSE_TEMPLATE, resp.message(), resp.code(), resp.responseClass())
                            : String.format(API_RESPONSE_TEMPLATE, resp.message(), resp.code(), resp.responseClass());
                    code = API_RESPONSE_PATTERN.matcher(code).replaceFirst(respAnnotation);
                    code = API_RESPONSE_PATTERN1.matcher(code).replaceFirst(respAnnotation);
                }
            }
            Matcher packageMatcher = PACKAGE_PATTERN.matcher(code);
            packageMatcher.find();
            String packageString = packageMatcher.group(0);
            code = packageMatcher.replaceFirst(RESOURCE_CLASS_HEADER_TEMPLATE.formatted(packageString));
            try (PrintWriter writer = new PrintWriter(processingEnv
                    .getFiler()
                    .createSourceFile(classElement.getQualifiedName().toString() + "Resource", classElement)
                    .openWriter())) {
                writer.print(code);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createExtender(TypeElement classElement) throws IOException {
        var qualifiedName = classElement.getQualifiedName().toString();
        var packageName = qualifiedName.substring(0, qualifiedName.lastIndexOf("."));
        var className = classElement.getSimpleName().toString();
        String sourceCode = generateSourceCode(packageName, qualifiedName, className, classElement);
        try (PrintWriter writer = new PrintWriter(processingEnv
                .getFiler()
                .createSourceFile(qualifiedName + "Extender", classElement)
                .openWriter())) {
            writer.print(sourceCode);
        }
    }

    private static TypeMirror getTypeMirror(ModelExtender annotation) {
        try {
            annotation.value(); // this should throw
        } catch (MirroredTypeException mte) {
            return mte.getTypeMirror();
        }
        return null; // can this ever happen ??
    }

    private static String getTypeMirror(ApiOperation annotation) {
        try {
            return annotation.value(); // this should throw
        } catch (MirroredTypeException mte) {
            return mte.getTypeMirror().toString();
        }
    }

    private static TypeMirror getTypeMirror(ApiResponse annotation) {
        try {
            annotation.response(); // this should throw
        } catch (MirroredTypeException mte) {
            return mte.getTypeMirror();
        }
        return null; // can this ever happen ??
    }

    private String capitalize(String str) {
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}
